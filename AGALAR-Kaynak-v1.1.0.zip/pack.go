package main

import (
	"context"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"time"
)

type LocalItem struct {
	Path string `json:"path"`
	Size int64  `json:"size"`
}

func scanSource(root string) ([]LocalItem, error) {
	if root == "" {
		return nil, nil
	}
	st, e := os.Stat(root)
	if e != nil {
		return nil, e
	}
	if !st.IsDir() {
		return nil, errors.New("Kaynak bir klasör olmalı")
	}
	var out []LocalItem
	e = filepath.Walk(root, func(p string, info os.FileInfo, err error) error {
		if err != nil {
			return err
		}
		if info.IsDir() {
			if p != root && info.Name() == ".agalar-trash" {
				return filepath.SkipDir
			}
			return nil
		}
		if !info.Mode().IsRegular() {
			return nil
		}
		rel, e := filepath.Rel(root, p)
		if e != nil {
			return e
		}
		if _, e = safeRelative(filepath.ToSlash(rel)); e != nil {
			return nil
		}
		out = append(out, LocalItem{filepath.ToSlash(rel), info.Size()})
		if len(out) > 20000 {
			return errors.New("20.000 dosya sınırı aşıldı")
		}
		return nil
	})
	sort.Slice(out, func(i, j int) bool { return out[i].Path < out[j].Path })
	return out, e
}
func safeLeaf(name string) string {
	name = strings.ReplaceAll(name, "\\", "/")
	return filepath.Base(name)
}
func uploadLocal(root, category, relative string, src io.Reader, limit int64) (string, error) {
	if !categories[category] {
		return "", errors.New("Desteklenmeyen tür")
	}
	relative = strings.ReplaceAll(relative, "\\", "/")
	relative = strings.TrimPrefix(relative, "/")
	// With webkitdirectory, the first segment is the chosen folder name. Keep the relative folder structure inside the selected category.
	if strings.HasPrefix(relative, category+"/") {
		relative = strings.TrimPrefix(relative, category+"/")
	}
	clean, e := safeRelative(category + "/" + relative)
	if e != nil {
		return "", e
	}
	dest := filepath.Join(root, clean)
	if e = os.MkdirAll(filepath.Dir(dest), 0700); e != nil {
		return "", e
	}
	f, e := os.CreateTemp(filepath.Dir(dest), ".agalar-upload-*")
	if e != nil {
		return "", e
	}
	tmp := f.Name()
	defer os.Remove(tmp)
	n, e := io.Copy(f, io.LimitReader(src, limit+1))
	if e != nil {
		f.Close()
		return "", e
	}
	if n > limit {
		f.Close()
		return "", errors.New("Dosya çok büyük")
	}
	if e = f.Close(); e != nil {
		return "", e
	}
	if _, e = os.Stat(dest); e == nil {
		backup := filepath.Join(root, ".agalar-trash", time.Now().UTC().Format("20060102-150405"), clean)
		if e = fileCopy(backup, dest); e != nil {
			return "", e
		}
		if e = os.Remove(dest); e != nil {
			return "", e
		}
	}
	if e = os.Rename(tmp, dest); e != nil {
		return "", e
	}
	return filepath.ToSlash(clean), nil
}
func removeLocal(root, rel string) error {
	clean, e := safeRelative(rel)
	if e != nil {
		return e
	}
	src := filepath.Join(root, clean)
	backup := filepath.Join(root, ".agalar-trash", time.Now().UTC().Format("20060102-150405"), clean)
	if e = os.MkdirAll(filepath.Dir(backup), 0700); e != nil {
		return e
	}
	return os.Rename(src, backup)
}
func (a *App) publishPack(version, notes, token string) error {
	if token == "" {
		return errors.New("Yayınlamak için GitHub erişim anahtarı gerekli")
	}
	if !validVersion(version) {
		return errors.New("Sürüm biçimi 1.0.1 gibi olmalı")
	}
	a.mu.Lock()
	source := a.cfg.Source
	a.mu.Unlock()
	if source == "" {
		return errors.New("Önce mod paketi kaynak klasörünü seç")
	}
	items, e := scanSource(source)
	if e != nil {
		return e
	}
	if len(items) == 0 {
		return errors.New("Kaynakta mod / paket dosyası yok")
	}
	ctx, cancel := context.WithTimeout(context.Background(), 4*time.Hour)
	defer cancel()
	releaseTag := "pack-v" + version
	releases, e := listReleases(ctx)
	if e != nil {
		return e
	}
	for _, r := range releases {
		if r.Tag == releaseTag {
			return errors.New("Bu sürüm zaten yayınlanmış; daha yüksek sürüm yaz")
		}
	}
	existing := map[string]PackFile{}
	oldR, found, e := newestRelease(ctx, "pack-v")
	if e != nil {
		return e
	}
	if found {
		old, e := fetchPackManifest(ctx, oldR)
		if e != nil {
			return e
		}
		for _, it := range old.Files {
			existing[it.SHA256] = it
		}
	}
	a.status.set(true, "Modlar hazırlanıyor...", "Dosyalar taranıyor", 2)
	contents := make([]PackFile, 0, len(items))
	toUpload := map[string]string{}
	for i, it := range items {
		full := filepath.Join(source, filepath.FromSlash(it.Path))
		digest, size, e := shaFile(full)
		if e != nil {
			return e
		}
		p := PackFile{Path: it.Path, Size: size, SHA256: digest}
		if old, ok := existing[digest]; ok && old.Size == size {
			p.URL = old.URL
		} else {
			toUpload[digest] = full
		}
		contents = append(contents, p)
		a.status.set(true, "Modlar hazırlanıyor...", fmt.Sprintf("%d / %d dosya", i+1, len(items)), 2+int(float64(i+1)/float64(len(items))*18))
	}
	if found && versionCmp(version, strings.TrimPrefix(oldR.Tag, "pack-v")) <= 0 {
		return errors.New("Yeni paket sürümü mevcut sürümden büyük olmalı")
	}
	draft, e := createDraft(ctx, token, releaseTag)
	if e != nil {
		return e
	}
	keys := make([]string, 0, len(toUpload))
	for k := range toUpload {
		keys = append(keys, k)
	}
	sort.Strings(keys)
	uploaded := map[string]string{}
	for i, k := range keys {
		full := toUpload[k]
		a.status.set(true, "Dosyalar GitHub'a yükleniyor...", fmt.Sprintf("%d / %d", i+1, len(keys)), 20+int(float64(i)/float64(maxInt(len(keys), 1))*70))
		remote, e := uploadAsset(ctx, token, draft, "obj-"+k, full)
		if e != nil {
			return fmt.Errorf("Yükleme başarısız. GitHub'da taslak sürüm bırakıldı (yeniden denemeden önce sil): %w", e)
		}
		uploaded[k] = remote.URL
	}
	for i := range contents {
		if contents[i].URL == "" {
			contents[i].URL = uploaded[contents[i].SHA256]
		}
	}
	sortedPackFiles(contents)
	manifest := PackManifest{Version: version, Minecraft: minecraftVersion, Forge: forgeVersion, Notes: notes, Files: contents}
	temp, e := os.CreateTemp("", "agalar-manifest-*.json")
	if e != nil {
		return e
	}
	defer os.Remove(temp.Name())
	if e = json.NewEncoder(temp).Encode(manifest); e != nil {
		temp.Close()
		return e
	}
	if e = temp.Close(); e != nil {
		return e
	}
	if _, e = uploadAsset(ctx, token, draft, "pack-manifest.json", temp.Name()); e != nil {
		return fmt.Errorf("Manifest yüklenemedi, taslak sürüm GitHub'da bırakıldı: %w", e)
	}
	a.status.set(true, "Yayın sonlandırılıyor...", "GitHub sürümü herkes için açılıyor", 96)
	if e = publishDraft(ctx, token, draft.ID); e != nil {
		return fmt.Errorf("Sürüm taslakta kaldı: %w", e)
	}
	return nil
}
func maxInt(a, b int) int {
	if a > b {
		return a
	}
	return b
}
func validVersion(v string) bool {
	parts := strings.Split(v, ".")
	if len(parts) != 3 {
		return false
	}
	for _, s := range parts {
		if s == "" || len(s) > 6 {
			return false
		}
		for _, r := range s {
			if r < '0' || r > '9' {
				return false
			}
		}
	}
	return true
}
func (a *App) installPack() error {
	a.mu.Lock()
	root := a.cfg.Profile
	a.mu.Unlock()
	if root == "" {
		return errors.New("Önce Minecraft profil klasörünü seç")
	}
	st, e := os.Stat(root)
	if e != nil {
		return e
	}
	if !st.IsDir() {
		return errors.New("Profil bir klasör olmalı")
	}
	ctx, cancel := context.WithTimeout(context.Background(), 4*time.Hour)
	defer cancel()
	r, ok, e := newestRelease(ctx, "pack-v")
	if e != nil {
		return e
	}
	if !ok {
		return errors.New("GitHub'da henüz mod paketi yayınlanmamış")
	}
	p, e := fetchPackManifest(ctx, r)
	if e != nil {
		return e
	}
	installed := readInstalled(root)
	old := map[string]string{}
	for _, x := range installed.Files {
		old[x.Path] = x.SHA256
	}
	backups := backupDir()
	items := len(p.Files)
	var processed int
	for _, f := range p.Files {
		dest, e := localFilePath(root, f.Path)
		if e != nil {
			return e
		}
		a.status.set(true, "Mod paketi kuruluyor...", fmt.Sprintf("%d / %d · %s", processed+1, items, f.Path), int(float64(processed)/float64(maxInt(items, 1))*90))
		current, _, err := shaFile(dest)
		if err == nil && strings.EqualFold(current, f.SHA256) {
			processed++
			continue
		}
		temp := dest + ".agalar-new-" + randomToken()[:8]
		if e = downloadVerified(ctx, f.URL, temp, f.SHA256, f.Size, nil); e != nil {
			return fmt.Errorf("%s: %w", f.Path, e)
		}
		if err == nil {
			b := filepath.Join(backups, filepath.FromSlash(f.Path))
			if e = fileCopy(b, dest); e != nil {
				os.Remove(temp)
				return fmt.Errorf("Eski dosya yedeklenemedi: %w", e)
			}
			if e = os.Remove(dest); e != nil {
				os.Remove(temp)
				return e
			}
		}
		if e = os.Rename(temp, dest); e != nil {
			return e
		}
		processed++
	}
	// Never touch untracked files or player worlds. Previously-managed obsolete files are saved as backups, not deleted forever.
	next := map[string]bool{}
	for _, f := range p.Files {
		next[f.Path] = true
	}
	for _, f := range installed.Files {
		if next[f.Path] {
			continue
		}
		dest, e := localFilePath(root, f.Path)
		if e != nil {
			continue
		}
		digest, _, e := shaFile(dest)
		if e != nil || !strings.EqualFold(digest, f.SHA256) {
			continue
		}
		bak := filepath.Join(backups, filepath.FromSlash(f.Path))
		if e = fileCopy(bak, dest); e != nil {
			return e
		}
		if e = os.Remove(dest); e != nil {
			return e
		}
	}
	result := Installed{Version: p.Version}
	for _, f := range p.Files {
		result.Files = append(result.Files, InstalledFile{Path: f.Path, SHA256: f.SHA256})
	}
	if e = atomicJSON(installedPath(root), result); e != nil {
		return e
	}
	// Data packs are staged in the profile's datapacks directory. Existing worlds are
	// only changed with a separate, explicit confirmation by the player.
	a.status.set(true, "Kurulum tamamlandı", fmt.Sprintf("%d dosya, sürüm %s", len(p.Files), p.Version), 100)
	return nil
}
func applyDatapacks(root string, p PackManifest, backups string) error {
	// Global staging area is 'datapacks'. Minecraft reads data packs from saves/<world>/datapacks.
	worlds, e := os.ReadDir(filepath.Join(root, "saves"))
	if os.IsNotExist(e) {
		return nil
	}
	if e != nil {
		return e
	}
	for _, world := range worlds {
		if !world.IsDir() {
			continue
		}
		wDir := filepath.Join(root, "saves", world.Name())
		if _, e = os.Stat(filepath.Join(wDir, "level.dat")); e != nil {
			continue
		}
		for _, f := range p.Files {
			if !strings.HasPrefix(f.Path, "datapacks/") {
				continue
			}
			rel := strings.TrimPrefix(f.Path, "datapacks/")
			if rel == "" {
				continue
			}
			to := filepath.Join(wDir, "datapacks", filepath.FromSlash(rel))
			from := filepath.Join(root, filepath.FromSlash(f.Path))
			digest, _, e := shaFile(to)
			if e == nil && strings.EqualFold(digest, f.SHA256) {
				continue
			}
			if e == nil {
				bak := filepath.Join(backups, "world-datapacks", world.Name(), filepath.FromSlash(rel))
				if e = fileCopy(bak, to); e != nil {
					return e
				}
			}
			if e = fileCopy(to, from); e != nil {
				return e
			}
		}
	}
	return nil
}
func hashBytes(b []byte) string { sum := sha256.Sum256(b); return hex.EncodeToString(sum[:]) }

func (a *App) applyWorldDatapacks() error {
	a.mu.Lock()
	profile := a.cfg.Profile
	a.mu.Unlock()
	if profile == "" {
		return errors.New("Önce Minecraft profil klasörünü seç")
	}
	installed := readInstalled(profile)
	if installed.Version == "" {
		return errors.New("Önce mod paketini kur")
	}
	ctx, cancel := context.WithTimeout(context.Background(), 90*time.Second)
	defer cancel()
	rel, ok, e := newestRelease(ctx, "pack-v")
	if e != nil {
		return e
	}
	if !ok {
		return errors.New("Paket sürümü yok")
	}
	pack, e := fetchPackManifest(ctx, rel)
	if e != nil {
		return e
	}
	if pack.Version != installed.Version {
		return errors.New("Önce mod paketini güncelle")
	}
	if err := applyDatapacks(profile, pack, backupDir()); err != nil {
		return err
	}
	return nil
}
