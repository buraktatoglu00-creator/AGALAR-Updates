package main

import (
	"context"
	"crypto/sha256"
	"embed"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"log"
	"net"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"strconv"
	"strings"
	"sync"
	"time"
)

// adminBuild is set only for the private administrator binary, never for public releases.
var adminBuild = "false"

func allowsAdmin() bool { return adminBuild == "true" }

//go:embed ui.html
var assets embed.FS

type App struct {
	mu              sync.Mutex
	cfg             Config
	status          Status
	token           string
	launched        time.Time
	lastRequest     time.Time
	busy            bool
	latestPack      string
	latestApp       string
	remotePackFiles int
	remoteErr       string
	cancel          context.CancelFunc
}

func (a *App) httpJSON(w http.ResponseWriter, status int, v any) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	w.Header().Set("Cache-Control", "no-store")
	w.WriteHeader(status)
	_ = json.NewEncoder(w).Encode(v)
}
func (a *App) fail(w http.ResponseWriter, err error) {
	a.httpJSON(w, 400, map[string]any{"error": err.Error()})
}
func (a *App) handle(w http.ResponseWriter, r *http.Request) {
	if r.URL.Path == "/" && r.Method == "GET" {
		buf, e := assets.ReadFile("ui.html")
		if e != nil {
			http.Error(w, "Arayüz yüklenemedi", 500)
			return
		}
		html := strings.ReplaceAll(string(buf), "__AGALAR_TOKEN__", a.token)
		html = strings.ReplaceAll(html, "__AGALAR_VERSION__", appVersion)
		w.Header().Set("Content-Type", "text/html; charset=utf-8")
		w.Header().Set("Cache-Control", "no-store")
		w.Header().Set("Content-Security-Policy", "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; object-src 'none'; frame-ancestors 'none'")
		w.Write([]byte(html))
		return
	}
	if !strings.HasPrefix(r.URL.Path, "/api/") {
		http.NotFound(w, r)
		return
	}
	if r.Header.Get("X-AGALAR-Token") != a.token {
		http.Error(w, "Yetkisiz", 403)
		return
	}
	if o := r.Header.Get("Origin"); o != "" && !(strings.HasPrefix(o, "http://127.0.0.1:") || strings.HasPrefix(o, "http://localhost:")) {
		http.Error(w, "Origin engellendi", 403)
		return
	}
	a.mu.Lock()
	a.lastRequest = time.Now()
	a.mu.Unlock()
	if r.Method != "POST" && r.Method != "GET" {
		http.Error(w, "Yöntem engellendi", 405)
		return
	}
	if r.Method == "POST" && !strings.HasPrefix(r.URL.Path, "/api/upload") {
		r.Body = http.MaxBytesReader(w, r.Body, 1<<20)
	}
	switch r.URL.Path {
	case "/api/state":
		a.mu.Lock()
		cfg := a.cfg
		pack := a.latestPack
		ver := a.latestApp
		err := a.remoteErr
		count := a.remotePackFiles
		busy := a.busy
		a.mu.Unlock()
		installed := readInstalled(cfg.Profile)
		a.httpJSON(w, 200, map[string]any{"app_version": appVersion, "admin_edition": allowsAdmin(), "minecraft": minecraftVersion, "forge": forgeVersion, "config": cfg, "installed": installed.Version, "installed_count": len(installed.Files), "remote_pack": pack, "remote_files": count, "remote_app": ver, "remote_error": err, "busy": busy, "status": a.status.snapshot()})
	case "/api/mode":
		var req struct {
			Admin bool `json:"admin"`
		}
		if e := json.NewDecoder(r.Body).Decode(&req); e != nil {
			a.fail(w, e)
			return
		}
		a.mu.Lock()
		if req.Admin && !allowsAdmin() {
			a.mu.Unlock()
			a.fail(w, errors.New("Yönetici araçları yalnızca özel yönetici sürümünde bulunur"))
			return
		}
		a.cfg.Admin = req.Admin && allowsAdmin()
		e := writeConfig(a.cfg)
		a.mu.Unlock()
		if e != nil {
			a.fail(w, e)
			return
		}
		a.httpJSON(w, 200, map[string]any{"ok": true})
	case "/api/select-folder":
		if r.Method != "POST" {
			a.fail(w, errors.New("POST gerekli"))
			return
		}
		folder, e := nativeChooseFolder()
		if e != nil {
			a.fail(w, e)
			return
		}
		a.httpJSON(w, 200, map[string]any{"path": folder})
	case "/api/config":
		var req struct {
			Profile *string `json:"profile"`
			Source  *string `json:"source"`
		}
		if e := json.NewDecoder(r.Body).Decode(&req); e != nil {
			a.fail(w, e)
			return
		}
		a.mu.Lock()
		if req.Profile != nil {
			a.cfg.Profile = strings.TrimSpace(*req.Profile)
		}
		if req.Source != nil && allowsAdmin() && a.cfg.Admin {
			a.cfg.Source = strings.TrimSpace(*req.Source)
		}
		e := writeConfig(a.cfg)
		a.mu.Unlock()
		if e != nil {
			a.fail(w, e)
			return
		}
		a.httpJSON(w, 200, map[string]any{"ok": true})
	case "/api/files":
		if !allowsAdmin() {
			a.fail(w, errors.New("Yönetici sürümü gerekli"))
			return
		}
		a.mu.Lock()
		src := a.cfg.Source
		a.mu.Unlock()
		items, e := scanSource(src)
		if e != nil {
			a.fail(w, e)
			return
		}
		a.httpJSON(w, 200, map[string]any{"files": items})
	case "/api/contents":
		a.mu.Lock()
		profile := a.cfg.Profile
		source := a.cfg.Source
		admin := a.cfg.Admin && allowsAdmin()
		a.mu.Unlock()
		if admin && r.URL.Query().Get("source") == "local" {
			items, e := sourceContents(source)
			if e != nil {
				a.fail(w, e)
				return
			}
			a.httpJSON(w, 200, map[string]any{"files": items, "origin": "local"})
		} else {
			ctx, cancel := context.WithTimeout(r.Context(), 45*time.Second)
			defer cancel()
			items, version, e := publishedContents(ctx, profile)
			if e != nil {
				a.fail(w, e)
				return
			}
			a.httpJSON(w, 200, map[string]any{"files": items, "origin": "published", "version": version})
		}
	case "/api/compare":
		a.mu.Lock()
		source := a.cfg.Source
		admin := a.cfg.Admin && allowsAdmin()
		a.mu.Unlock()
		if !admin {
			a.fail(w, errors.New("Yönetici sürümü gerekli"))
			return
		}
		ctx, cancel := context.WithTimeout(r.Context(), 2*time.Minute)
		defer cancel()
		diff, e := compareSourceToPublished(ctx, source)
		if e != nil {
			a.fail(w, e)
			return
		}
		a.httpJSON(w, 200, diff)
	case "/api/config-read":
		a.mu.Lock()
		source := a.cfg.Source
		admin := a.cfg.Admin && allowsAdmin()
		a.mu.Unlock()
		if !admin {
			a.fail(w, errors.New("Yönetici sürümü gerekli"))
			return
		}
		content, e := readSourceConfig(source, r.URL.Query().Get("path"))
		if e != nil {
			a.fail(w, e)
			return
		}
		a.httpJSON(w, 200, map[string]any{"content": content})
	case "/api/config-save":
		if r.Method != "POST" {
			a.fail(w, errors.New("POST gerekli"))
			return
		}
		a.mu.Lock()
		source := a.cfg.Source
		admin := a.cfg.Admin && allowsAdmin()
		a.mu.Unlock()
		if !admin {
			a.fail(w, errors.New("Yönetici sürümü gerekli"))
			return
		}
		var req struct {
			Path    string `json:"path"`
			Content string `json:"content"`
		}
		if e := json.NewDecoder(r.Body).Decode(&req); e != nil {
			a.fail(w, e)
			return
		}
		if e := saveSourceConfig(source, req.Path, req.Content); e != nil {
			a.fail(w, e)
			return
		}
		a.httpJSON(w, 200, map[string]any{"ok": true})
	case "/api/preset":
		if r.Method != "POST" {
			a.fail(w, errors.New("POST gerekli"))
			return
		}
		var req struct {
			Name string `json:"name"`
		}
		if e := json.NewDecoder(r.Body).Decode(&req); e != nil {
			a.fail(w, e)
			return
		}
		a.mu.Lock()
		profile := a.cfg.Profile
		a.mu.Unlock()
		if e := applyPlayerPreset(profile, req.Name); e != nil {
			a.fail(w, e)
			return
		}
		a.httpJSON(w, 200, map[string]any{"ok": true})
	case "/api/export-server":
		if r.Method != "POST" {
			a.fail(w, errors.New("POST gerekli"))
			return
		}
		a.mu.Lock()
		source := a.cfg.Source
		admin := a.cfg.Admin && allowsAdmin()
		a.mu.Unlock()
		if !admin {
			a.fail(w, errors.New("Yönetici sürümü gerekli"))
			return
		}
		var req struct {
			Target string `json:"target"`
		}
		if e := json.NewDecoder(r.Body).Decode(&req); e != nil {
			a.fail(w, e)
			return
		}
		count, e := exportServerConfigs(source, strings.TrimSpace(req.Target))
		if e != nil {
			a.fail(w, e)
			return
		}
		a.httpJSON(w, 200, map[string]any{"ok": true, "count": count})
	case "/api/upload":
		if r.Method != "POST" {
			a.fail(w, errors.New("POST gerekli"))
			return
		}
		a.mu.Lock()
		src := a.cfg.Source
		admin := a.cfg.Admin
		a.mu.Unlock()
		if !admin || !allowsAdmin() {
			a.fail(w, errors.New("Yönetici modu kapalı"))
			return
		}
		if src == "" {
			a.fail(w, errors.New("Önce kaynak klasörü seç"))
			return
		}
		r.Body = http.MaxBytesReader(w, r.Body, 8<<30)
		if e := r.ParseMultipartForm(32 << 20); e != nil {
			a.fail(w, e)
			return
		}
		if r.MultipartForm != nil {
			defer r.MultipartForm.RemoveAll()
		}
		category := r.FormValue("category")
		files := r.MultipartForm.File["files"]
		if len(files) == 0 || len(files) > 5000 {
			a.fail(w, errors.New("1-5000 dosya seçilebilir"))
			return
		}
		added := 0
		paths := r.MultipartForm.Value["relative"]
		for i, fh := range files {
			rel := safeLeaf(fh.Filename)
			if i < len(paths) && paths[i] != "" {
				rel = paths[i]
			}
			f, e := fh.Open()
			if e != nil {
				a.fail(w, e)
				return
			}
			_, e = uploadLocal(src, category, rel, f, 2<<30)
			f.Close()
			if e != nil {
				a.fail(w, e)
				return
			}
			added++
		}
		a.httpJSON(w, 200, map[string]any{"added": added})
	case "/api/remove":
		a.mu.Lock()
		src := a.cfg.Source
		admin := a.cfg.Admin
		a.mu.Unlock()
		if !admin || !allowsAdmin() {
			a.fail(w, errors.New("Yönetici modu kapalı"))
			return
		}
		var req struct {
			Path string `json:"path"`
		}
		if e := json.NewDecoder(r.Body).Decode(&req); e != nil {
			a.fail(w, e)
			return
		}
		if e := removeLocal(src, req.Path); e != nil {
			a.fail(w, e)
			return
		}
		a.httpJSON(w, 200, map[string]any{"ok": true})
	case "/api/check":
		if e := a.startTask("GitHub sürümleri kontrol ediliyor...", a.checkRemote); e != nil {
			a.fail(w, e)
			return
		}
		a.httpJSON(w, 202, map[string]any{"ok": true})
	case "/api/install":
		if e := a.startTask("Mod paketi kuruluyor...", a.installPack); e != nil {
			a.fail(w, e)
			return
		}
		a.httpJSON(w, 202, map[string]any{"ok": true})
	case "/api/apply-datapacks":
		if r.Method != "POST" {
			a.fail(w, errors.New("POST gerekli"))
			return
		}
		if e := a.startTask("Data Pack dosyaları dünyalara uygulanıyor...", a.applyWorldDatapacks); e != nil {
			a.fail(w, e)
			return
		}
		a.httpJSON(w, 202, map[string]any{"ok": true})
	case "/api/update-app":
		if allowsAdmin() {
			a.fail(w, errors.New("Özel yönetici sürümü oyuncu güncellemesiyle değiştirilmez"))
			return
		}
		if e := a.startTask("Uygulama güncelleniyor...", a.updateSelf); e != nil {
			a.fail(w, e)
			return
		}
		a.httpJSON(w, 202, map[string]any{"ok": true})
	case "/api/publish":
		a.mu.Lock()
		admin := a.cfg.Admin
		a.mu.Unlock()
		if !admin || !allowsAdmin() {
			a.fail(w, errors.New("Yönetici modu kapalı"))
			return
		}
		var req struct {
			Version string `json:"version"`
			Notes   string `json:"notes"`
			Token   string `json:"token"`
		}
		if e := json.NewDecoder(r.Body).Decode(&req); e != nil {
			a.fail(w, e)
			return
		}
		if e := a.startTask("Mod paketi hazırlanıyor...", func() error {
			return a.publishPack(strings.TrimSpace(req.Version), req.Notes, strings.TrimSpace(req.Token))
		}); e != nil {
			a.fail(w, e)
			return
		}
		a.httpJSON(w, 202, map[string]any{"ok": true})
	case "/api/quit":
		a.httpJSON(w, 200, map[string]any{"ok": true})
		go func() { time.Sleep(250 * time.Millisecond); os.Exit(0) }()
	default:
		http.NotFound(w, r)
	}
}
func (a *App) startTask(message string, fn func() error) error {
	a.mu.Lock()
	if a.busy {
		a.mu.Unlock()
		return errors.New("Başka bir işlem sürüyor")
	}
	a.busy = true
	a.mu.Unlock()
	a.status.set(true, message, "", 0)
	go func() {
		err := fn()
		a.mu.Lock()
		a.busy = false
		a.mu.Unlock()
		if err != nil {
			a.status.set(false, "İşlem başarısız: "+err.Error(), "", 0)
		} else {
			a.status.set(false, "İşlem tamamlandı.", "", 100)
		}
	}()
	return nil
}
func (a *App) checkRemote() error {
	ctx, cancel := context.WithTimeout(context.Background(), 90*time.Second)
	defer cancel()
	appR, appFound, e := newestRelease(ctx, "app-v")
	if e != nil {
		a.mu.Lock()
		a.remoteErr = e.Error()
		a.mu.Unlock()
		return e
	}
	packR, packFound, e := newestRelease(ctx, "pack-v")
	if e != nil {
		a.mu.Lock()
		a.remoteErr = e.Error()
		a.mu.Unlock()
		return e
	}
	packVer := ""
	appVer := ""
	count := 0
	if appFound {
		manifest, _, e := fetchAppManifest(ctx, appR)
		if e != nil {
			return e
		}
		appVer = manifest.Version
	}
	if packFound {
		p, e := fetchPackManifest(ctx, packR)
		if e != nil {
			return e
		}
		packVer = p.Version
		count = len(p.Files)
	}
	a.mu.Lock()
	a.latestPack = packVer
	a.latestApp = appVer
	a.remotePackFiles = count
	a.remoteErr = ""
	a.mu.Unlock()
	if !appFound && !packFound {
		a.status.set(true, "GitHub deposu hazır ama henüz yayın yok.", "İlk sürüm yayınlandıktan sonra burada görünecek.", 100)
	}
	return nil
}
func openWindow(url string) (*exec.Cmd, error) {
	if runtime.GOOS != "windows" {
		return nil, errors.New("Windows uygulaması")
	}
	candidates := []string{}
	for _, base := range []string{os.Getenv("PROGRAMFILES(X86)"), os.Getenv("PROGRAMFILES"), os.Getenv("LOCALAPPDATA")} {
		if base != "" {
			candidates = append(candidates, filepath.Join(base, "Microsoft", "Edge", "Application", "msedge.exe"), filepath.Join(base, "Google", "Chrome", "Application", "chrome.exe"))
		}
	}
	candidates = append(candidates, "msedge.exe", "chrome.exe")
	for _, p := range candidates {
		if strings.Contains(p, "\\") || strings.Contains(p, "/") {
			if _, e := os.Stat(p); e != nil {
				continue
			}
		}
		cmd := exec.Command(p, "--app="+url, "--window-size=1120,785", "--new-window")
		if e := cmd.Start(); e == nil {
			return cmd, nil
		}
	}
	// The application still works in the system's default browser if Edge is unavailable.
	cmd := exec.Command("rundll32.exe", "url.dll,FileProtocolHandler", url)
	if e := cmd.Start(); e != nil {
		return nil, e
	}
	return cmd, nil
}
func main() {
	if len(os.Args) > 1 && os.Args[1] == "--replace" {
		if e := replaceSelf(os.Args[2:]); e != nil {
			log.Print(e)
		}
		return
	}
	cfg := readConfig()
	if !allowsAdmin() {
		cfg.Admin = false
	}
	a := &App{cfg: cfg, token: randomToken(), launched: time.Now(), lastRequest: time.Now()}
	a.status.set(false, "Hazır. Profil klasörünü seçerek başlayabilirsin.", "", 0)
	mux := http.NewServeMux()
	mux.HandleFunc("/", a.handle)
	server := &http.Server{Handler: mux, ReadHeaderTimeout: 10 * time.Second, MaxHeaderBytes: 16 << 10}
	listener, e := net.Listen("tcp", "127.0.0.1:0")
	if e != nil {
		log.Fatal(e)
	}
	port := listener.Addr().(*net.TCPAddr).Port
	url := "http://127.0.0.1:" + strconv.Itoa(port) + "/"
	if runtime.GOOS != "windows" {
		log.Printf("AGALAR UI: %s", url)
	}
	go func() {
		if e := server.Serve(listener); e != nil && e != http.ErrServerClosed {
			log.Printf("local server: %v", e)
		}
	}()
	if _, e = openWindow(url); e != nil {
		log.Printf("Pencere açılamadı: %v", e)
	}
	go func() { _ = a.startTask("Sürümler kontrol ediliyor...", a.checkRemote) }()
	// Closing the app-window ends the local server after a grace period. Long-running operations are not interrupted.
	ticker := time.NewTicker(12 * time.Second)
	defer ticker.Stop()
	for range ticker.C {
		a.mu.Lock()
		idle := time.Since(a.lastRequest)
		active := a.busy
		uptime := time.Since(a.launched)
		a.mu.Unlock()
		if !active && uptime > 70*time.Second && idle > 42*time.Second {
			_ = server.Close()
			return
		}
	}
}

var _ = io.EOF
var _ = fmt.Sprintf
var _ = sha256.Size
var _ = hex.EncodeToString
