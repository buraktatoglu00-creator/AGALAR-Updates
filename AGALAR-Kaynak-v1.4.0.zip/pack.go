package main

import (
	"context"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"time"
)

type LocalItem struct {
	Path string `json:"path"`
	Size int64  `json:"size"`
}

func scanSource(root string) ([]LocalItem, error) {
	if root == "" {
		return nil, nil
	}
	st, e := os.Stat(root)
	if e != nil {
		return nil, e
	}
	if !st.IsDir() {
		return nil, errors.New("Kaynak bir klasör olmalı")
	}
	var out []LocalItem
	e = filepath.Walk(root, func(p string, info os.FileInfo, err error) error {
		if err != nil {
			return err
		}
		if info.IsDir() {
			if p != root && info.Name() == ".agalar-trash" {
				return filepath.SkipDir
			}
			return nil
		}
		if !info.Mode().IsRegular() {
			return nil
		}
		rel, e := filepath.Rel(root, p)
		if e != nil {
			return e
		}
		if _, e = safeRelative(filepath.ToSlash(rel)); e != nil {
			return nil
		}
		out = append(out, LocalItem{filepath.ToSlash(rel), info.Size()})
		if len(out) > 20000 {
			return errors.New("20.000 dosya sınırı aşıldı")
		}
		return nil
	})
	sort.Slice(out, func(i, j int) bool { return out[i].Path < out[j].Path })
	return out, e
}
func safeLeaf(name string) string {
	name = strings.ReplaceAll(name, "\\", "/")
	return filepath.Base(name)
}
func uploadLocal(root, category, relative string, src io.Reader, limit int64) (string, error) {
	if !categories[category] {
		return "", errors.New("Desteklenmeyen tür")
	}
	if !allowedContentExtension(category, relative) {
		return "", errors.New("Dosya türü seçilen kategoriyle uyumlu değil: " + safeLeaf(relative))
	}
	relative = strings.ReplaceAll(relative, "\\", "/")
	relative = strings.TrimPrefix(relative, "/")
	// With webkitdirectory, the first segment is the chosen folder name. Keep the relative folder structure inside the selected category.
	if strings.HasPrefix(relative, category+"/") {
		relative = strings.TrimPrefix(relative, category+"/")
	}
	clean, e := safeRelative(category + "/" + relative)
	if e != nil {
		return "", e
	}
	dest := filepath.Join(root, clean)
	if e := checkSourceParents(root, dest); e != nil {
		return "", e
	}
	if e = os.MkdirAll(filepath.Dir(dest), 0700); e != nil {
		return "", e
	}
	f, e := os.CreateTemp(filepath.Dir(dest), ".agalar-upload-*")
	if e != nil {
		return "", e
	}
	tmp := f.Name()
	defer os.Remove(tmp)
	n, e := io.Copy(f, io.LimitReader(src, limit+1))
	if e != nil {
		f.Close()
		return "", e
	}
	if n > limit {
		f.Close()
		return "", errors.New("Dosya çok büyük")
	}
	if e = f.Close(); e != nil {
		return "", e
	}
	if old, statErr := os.Lstat(dest); statErr == nil {
		if !old.Mode().IsRegular() {
			return "", errors.New("Üzerine yazılacak hedef normal dosya değil")
		}
		oldHash, oldSize, hashErr := shaFile(dest)
		newHash, newSize, newErr := shaFile(tmp)
		if hashErr == nil && newErr == nil && oldSize == newSize && oldHash == newHash {
			return "", nil // Identical file: no change or backup needed.
		}
		backup := filepath.Join(root, ".agalar-trash", time.Now().UTC().Format("20060102-150405"), clean)
		if e = fileCopy(backup, dest); e != nil {
			return "", e
		}
		if e = os.Remove(dest); e != nil {
			return "", e
		}
	}
	if e = os.Rename(tmp, dest); e != nil {
		return "", e
	}
	return filepath.ToSlash(clean), nil
}
func removeLocal(root, rel string) error {
	clean, e := safeRelative(rel)
	if e != nil {
		return e
	}
	src := filepath.Join(root, clean)
	backup := filepath.Join(root, ".agalar-trash", time.Now().UTC().Format("20060102-150405"), clean)
	if e = os.MkdirAll(filepath.Dir(backup), 0700); e != nil {
		return e
	}
	return os.Rename(src, backup)
}
func (a *App) publishPack(version, notes, token string) error {
	if token == "" {
		return errors.New("Yayınlamak için GitHub erişim anahtarı gerekli")
	}
	if !validVersion(version) {
		return errors.New("Sürüm biçimi 1.0.1 gibi olmalı")
	}
	a.mu.Lock()
	source := a.cfg.Source
	a.mu.Unlock()
	if source == "" {
		return errors.New("Önce mod paketi kaynak klasörünü seç")
	}
	items, e := scanSource(source)
	if e != nil {
		return e
	}
	if len(items) == 0 {
		return errors.New("Kaynakta mod / paket dosyası yok")
	}
	ctx, cancel := context.WithTimeout(context.Background(), 4*time.Hour)
	defer cancel()
	releaseTag := "pack-v" + version
	releases, e := listReleases(ctx)
	if e != nil {
		return e
	}
	for _, r := range releases {
		if r.Tag == releaseTag {
			return errors.New("Bu sürüm zaten yayınlanmış; daha yüksek sürüm yaz")
		}
	}
	existing := map[string]PackFile{}
	oldR, found, e := newestRelease(ctx, "pack-v")
	if e != nil {
		return e
	}
	if found {
		old, e := fetchPackManifest(ctx, oldR)
		if e != nil {
			return e
		}
		// Invalid/deleted reused objects are uploaded again into the new release.
		currentAssets := make(map[string]ReleaseAsset)
		for _, r := range releases {
			if r.Draft || r.Prerelease || !strings.HasPrefix(r.Tag, "pack-v") {
				continue
			}
			for _, asset := range r.Assets {
				if strings.HasPrefix(asset.Name, "obj-") && safeAssetURL(asset.URL) == nil {
					currentAssets[asset.Name] = asset
				}
			}
		}
		for _, it := range old.Files {
			if asset, ok := currentAssets["obj-"+strings.ToLower(it.SHA256)]; ok && asset.Size == it.Size {
				// A deleted or corrupted previous release must never poison a
				// future pack. Missing assets are uploaded into this release.
				if assetReachable(ctx, asset.URL) {
					it.URL = asset.URL
					existing[it.SHA256] = it
				}
			}
		}
	}
	a.status.set(true, "Modlar hazırlanıyor...", "Dosyalar taranıyor", 2)
	contents := make([]PackFile, 0, len(items))
	toUpload := map[string]string{}
	for i, it := range items {
		full := filepath.Join(source, filepath.FromSlash(it.Path))
		digest, size, e := shaFile(full)
		if e != nil {
			return e
		}
		p := PackFile{Path: it.Path, Size: size, SHA256: digest}
		if old, ok := existing[digest]; ok && old.Size == size {
			// Reuse only if the object is still present in the published releases.
			// Otherwise re-upload rather than writing a stale URL to the manifest.
			if err := safeAssetURL(old.URL); err == nil {
				p.URL = old.URL
			} else {
				toUpload[digest] = full
			}
		} else {
			toUpload[digest] = full
		}
		contents = append(contents, p)
		a.status.set(true, "Modlar hazırlanıyor...", fmt.Sprintf("%d / %d dosya", i+1, len(items)), 2+int(float64(i+1)/float64(len(items))*18))
	}
	if found && versionCmp(version, strings.TrimPrefix(oldR.Tag, "pack-v")) <= 0 {
		return errors.New("Yeni paket sürümü mevcut sürümden büyük olmalı")
	}
	draft, e := createDraft(ctx, token, releaseTag)
	if e != nil {
		return e
	}
	keys := make([]string, 0, len(toUpload))
	for k := range toUpload {
		keys = append(keys, k)
	}
	sort.Strings(keys)
	uploaded := map[string]string{}
	for i, k := range keys {
		full := toUpload[k]
		a.status.set(true, "Dosyalar GitHub'a yükleniyor...", fmt.Sprintf("%d / %d", i+1, len(keys)), 20+int(float64(i)/float64(maxInt(len(keys), 1))*70))
		remote, e := uploadAsset(ctx, token, draft, "obj-"+k, full)
		if e != nil {
			return fmt.Errorf("Yükleme başarısız. GitHub'da taslak sürüm bırakıldı (yeniden denemeden önce sil): %w", e)
		}
		uploaded[k] = remote.URL
	}
	for i := range contents {
		if contents[i].URL == "" {
			contents[i].URL = uploaded[contents[i].SHA256]
		}
	}
	sortedPackFiles(contents)
	manifest := PackManifest{Version: version, Minecraft: minecraftVersion, Forge: forgeVersion, Notes: notes, Files: contents}
	temp, e := os.CreateTemp("", "agalar-manifest-*.json")
	if e != nil {
		return e
	}
	defer os.Remove(temp.Name())
	if e = json.NewEncoder(temp).Encode(manifest); e != nil {
		temp.Close()
		return e
	}
	if e = temp.Close(); e != nil {
		return e
	}
	// Confirm the draft contains all newly uploaded objects before publishing.
	var checked GHRelease
	if e = githubJSON(ctx, "GET", fmt.Sprintf("/releases/%d", draft.ID), token, nil, &checked); e != nil {
		return fmt.Errorf("Yüklenen dosyalar doğrulanamadı: %w", e)
	}
	draftAssets := make(map[string]int64)
	for _, asset := range checked.Assets {
		draftAssets[asset.Name] = asset.Size
	}
	for hash, full := range toUpload {
		info, statErr := os.Stat(full)
		if statErr != nil {
			return statErr
		}
		if n, ok := draftAssets["obj-"+hash]; !ok || n != info.Size() {
			return fmt.Errorf("GitHub yükleme doğrulaması başarısız: obj-%s", hash)
		}
	}
	if _, e = uploadAsset(ctx, token, draft, "pack-manifest.json", temp.Name()); e != nil {
		return fmt.Errorf("Manifest yüklenemedi, taslak sürüm GitHub'da bırakıldı: %w", e)
	}
	a.status.set(true, "Yayın sonlandırılıyor...", "GitHub sürümü herkes için açılıyor", 96)
	if e = publishDraft(ctx, token, draft.ID); e != nil {
		return fmt.Errorf("Sürüm taslakta kaldı: %w", e)
	}
	return nil
}
func maxInt(a, b int) int {
	if a > b {
		return a
	}
	return b
}
func validVersion(v string) bool {
	parts := strings.Split(v, ".")
	if len(parts) != 3 {
		return false
	}
	for _, s := range parts {
		if s == "" || len(s) > 6 {
			return false
		}
		for _, r := range s {
			if r < '0' || r > '9' {
				return false
			}
		}
	}
	return true
}
func (a *App) installPack() error {
	a.mu.Lock()
	root := a.cfg.Profile
	a.mu.Unlock()
	if root == "" {
		return errors.New("Minecraft klasörü otomatik bulunamadı. Gelişmiş seçeneklerden bir kez oyun klasörünü seç")
	}
	validated, _, e := validateGameFolder(root)
	if e != nil {
		return e
	}
	root = validated
	ctx, cancel := context.WithTimeout(context.Background(), 4*time.Hour)
	defer cancel()
	if err := a.ensureForge(ctx, root); err != nil {
		return err
	}
	release, ok, e := newestRelease(ctx, "pack-v")
	if e != nil {
		return e
	}
	if !ok {
		return errors.New("GitHub'da henüz mod paketi yayınlanmamış")
	}
	p, e := fetchPackManifest(ctx, release)
	if e != nil {
		return e
	}
	p.Files, e = resolvePackAssets(ctx, release, p.Files)
	if e != nil {
		return e
	}
	previous := readInstalled(root)
	stageRoot := filepath.Join(dataDir(), "staging")
	if e = os.MkdirAll(stageRoot, 0700); e != nil {
		return e
	}
	stage, e := os.MkdirTemp(stageRoot, "pack-")
	if e != nil {
		return e
	}
	defer os.RemoveAll(stage)
	type staged struct {
		path           string
		dest           string
		temporary      string
		originalExists bool
		backup         string
		remove         bool
	}
	var changes []staged
	count := len(p.Files)
	a.status.set(true, "Dosyalar doğrulanıyor...", fmt.Sprintf("0 / %d", count), 1)
	for i, f := range p.Files {
		dest, err := localFilePath(root, f.Path)
		if err != nil {
			return err
		}
		if err = checkSourceParents(root, dest); err != nil {
			return err
		}
		st, err := os.Lstat(dest)
		if err != nil && !os.IsNotExist(err) {
			return err
		}
		if err == nil && !st.Mode().IsRegular() {
			return fmt.Errorf("Hedef normal bir dosya değil: %s", f.Path)
		}
		digest := ""
		if err == nil {
			digest, _, e = shaFile(dest)
			if e != nil {
				return e
			}
		}
		if strings.EqualFold(digest, f.SHA256) {
			continue
		}
		stageFile := filepath.Join(stage, filepath.FromSlash(f.Path))
		a.status.set(true, "Dosyalar indiriliyor...", fmt.Sprintf("%d / %d · %s", i+1, count, f.Path), int(float64(i)/float64(maxInt(count, 1))*75)+1)
		err = downloadPackObject(ctx, f, stageFile, func(bytes int64) {
			ratio := float64(bytes) / float64(maxInt64(f.Size, 1))
			if ratio > 1 {
				ratio = 1
			}
			pct := 1 + int((float64(i)+ratio)/float64(maxInt(count, 1))*75)
			a.status.set(true, "Dosyalar indiriliyor...", fmt.Sprintf("%d / %d · %s", i+1, count, f.Path), pct)
		})
		if err != nil {
			return fmt.Errorf("%s: %w. Oyun dosyalarına dokunulmadı", f.Path, err)
		}
		changes = append(changes, staged{path: f.Path, dest: dest, temporary: stageFile, originalExists: st != nil && err == nil})
	}
	// Only files that this manager previously installed are eligible for removal.
	keep := make(map[string]bool, len(p.Files))
	for _, f := range p.Files {
		keep[f.Path] = true
	}
	for _, f := range previous.Files {
		if keep[f.Path] {
			continue
		}
		dest, err := localFilePath(root, f.Path)
		if err != nil {
			return err
		}
		if err = checkSourceParents(root, dest); err != nil {
			return err
		}
		st, err := os.Lstat(dest)
		if os.IsNotExist(err) {
			continue
		}
		if err != nil {
			return err
		}
		if !st.Mode().IsRegular() {
			continue
		}
		digest, _, err := shaFile(dest)
		if err != nil {
			return err
		}
		if !strings.EqualFold(digest, f.SHA256) {
			continue
		} // User changed it; leave alone.
		changes = append(changes, staged{path: f.Path, dest: dest, originalExists: true, remove: true})
	}
	backup := backupDir()
	// Back up *all* existing destinations before modifying any game file.
	for i := range changes {
		c := &changes[i]
		if !c.originalExists {
			continue
		}
		c.backup = filepath.Join(backup, filepath.FromSlash(c.path))
		if e = fileCopy(c.backup, c.dest); e != nil {
			return fmt.Errorf("Eski dosyalar yedeklenemedi (oyun değişmedi): %w", e)
		}
	}
	applied := make([]staged, 0, len(changes))
	rollback := func(cause error) error {
		var failed []string
		for i := len(applied) - 1; i >= 0; i-- {
			c := applied[i]
			if c.originalExists {
				if e := fileCopy(c.dest, c.backup); e != nil {
					failed = append(failed, c.path+": "+e.Error())
				}
			} else if e := os.Remove(c.dest); e != nil && !os.IsNotExist(e) {
				failed = append(failed, c.path+": "+e.Error())
			}
		}
		if len(failed) > 0 {
			return fmt.Errorf("%w; geri yükleme eksik: %s (yedekler: %s)", cause, strings.Join(failed, ", "), backup)
		}
		return fmt.Errorf("%w. Eski dosyalar geri yüklendi", cause)
	}
	for i, c := range changes {
		if e = ctx.Err(); e != nil {
			return rollback(e)
		}
		a.status.set(true, "Mod paketi uygulanıyor...", fmt.Sprintf("%d / %d · %s", i+1, len(changes), c.path), 76+int(float64(i)/float64(maxInt(len(changes), 1))*23))
		if !c.remove {
			if e = os.MkdirAll(filepath.Dir(c.dest), 0700); e != nil {
				return rollback(e)
			}
		}
		// Track current file before any destructive change so failures restore it.
		applied = append(applied, c)
		if c.originalExists {
			if e = os.Remove(c.dest); e != nil {
				return rollback(e)
			}
		}
		if !c.remove {
			if e = os.Rename(c.temporary, c.dest); e != nil {
				return rollback(e)
			}
		}
	}
	result := Installed{Version: p.Version}
	for _, f := range p.Files {
		result.Files = append(result.Files, InstalledFile{Path: f.Path, SHA256: f.SHA256})
	}
	if len(changes) > 0 {
		paths := make([]string, 0, len(changes))
		saved := make([]InstalledFile, 0)
		for _, c := range changes {
			paths = append(paths, c.path)
			if c.originalExists {
				hash, _, hashErr := shaFile(c.backup)
				if hashErr != nil {
					return rollback(hashErr)
				}
				saved = append(saved, InstalledFile{Path: c.path, SHA256: hash})
			}
		}
		record := BackupRecord{Profile: root, Previous: previous, Updated: result, Changed: paths, Saved: saved, CreatedAt: time.Now().Format(time.RFC3339)}
		if e = atomicJSON(filepath.Join(backup, "agalar-backup.json"), record); e != nil {
			return rollback(e)
		}
	}
	if e = atomicJSON(installedPath(root), result); e != nil {
		return rollback(e)
	}
	a.status.set(true, "Kurulum doğrulandı", fmt.Sprintf("%d dosya · sürüm %s", len(p.Files), p.Version), 100)
	return nil
}

func applyDatapacks(root string, p PackManifest, backups string) error {
	// Global staging area is 'datapacks'. Minecraft reads data packs from saves/<world>/datapacks.
	worlds, e := os.ReadDir(filepath.Join(root, "saves"))
	if os.IsNotExist(e) {
		return nil
	}
	if e != nil {
		return e
	}
	for _, world := range worlds {
		if !world.IsDir() {
			continue
		}
		wDir := filepath.Join(root, "saves", world.Name())
		if _, e = os.Stat(filepath.Join(wDir, "level.dat")); e != nil {
			continue
		}
		for _, f := range p.Files {
			if !strings.HasPrefix(f.Path, "datapacks/") {
				continue
			}
			rel := strings.TrimPrefix(f.Path, "datapacks/")
			if rel == "" {
				continue
			}
			to := filepath.Join(wDir, "datapacks", filepath.FromSlash(rel))
			from := filepath.Join(root, filepath.FromSlash(f.Path))
			digest, _, e := shaFile(to)
			if e == nil && strings.EqualFold(digest, f.SHA256) {
				continue
			}
			if e == nil {
				bak := filepath.Join(backups, "world-datapacks", world.Name(), filepath.FromSlash(rel))
				if e = fileCopy(bak, to); e != nil {
					return e
				}
			}
			if e = fileCopy(to, from); e != nil {
				return e
			}
		}
	}
	return nil
}
func hashBytes(b []byte) string { sum := sha256.Sum256(b); return hex.EncodeToString(sum[:]) }

func (a *App) applyWorldDatapacks() error {
	a.mu.Lock()
	profile := a.cfg.Profile
	a.mu.Unlock()
	if profile == "" {
		return errors.New("Önce Minecraft profil klasörünü seç")
	}
	installed := readInstalled(profile)
	if installed.Version == "" {
		return errors.New("Önce mod paketini kur")
	}
	ctx, cancel := context.WithTimeout(context.Background(), 90*time.Second)
	defer cancel()
	rel, ok, e := newestRelease(ctx, "pack-v")
	if e != nil {
		return e
	}
	if !ok {
		return errors.New("Paket sürümü yok")
	}
	pack, e := fetchPackManifest(ctx, rel)
	if e != nil {
		return e
	}
	if pack.Version != installed.Version {
		return errors.New("Önce mod paketini güncelle")
	}
	if err := applyDatapacks(profile, pack, backupDir()); err != nil {
		return err
	}
	return nil
}

// Reject executable uploads and obvious wrong-category files before they enter a pack.
func allowedContentExtension(category, name string) bool {
	ext := strings.ToLower(filepath.Ext(name))
	switch category {
	case "mods":
		return ext == ".jar"
	case "resourcepacks":
		return ext == ".zip" || (strings.Contains(strings.ReplaceAll(name, "\\", "/"), "/") && oneOf(ext, ".png", ".json", ".mcmeta", ".properties", ".txt", ".ogg", ".ttf", ".otf", ".fsh", ".vsh", ".glsl"))
	case "shaderpacks":
		return ext == ".zip" || (strings.Contains(strings.ReplaceAll(name, "\\", "/"), "/") && oneOf(ext, ".fsh", ".vsh", ".glsl", ".json", ".properties", ".png", ".txt", ".lang"))
	case "datapacks":
		return ext == ".zip" || (strings.Contains(strings.ReplaceAll(name, "\\", "/"), "/") && oneOf(ext, ".json", ".mcmeta", ".mcfunction", ".txt", ".nbt", ".snbt"))
	case "config", "defaultconfigs":
		switch ext {
		case ".cfg", ".toml", ".json", ".json5", ".properties", ".txt", ".conf", ".yaml", ".yml", ".snbt", ".mcmeta":
			return true
		}
	case "kubejs", "scripts":
		switch ext {
		case ".js", ".zs", ".json", ".json5", ".toml", ".cfg", ".properties", ".txt", ".conf", ".mcmeta", ".snbt", ".yaml", ".yml", ".png", ".ogg", ".nbt", ".mcfunction":
			return true
		}
	}
	return false
}
func checkSourceParents(root, target string) error {
	// The source itself has already been selected by the administrator.
	base, err := filepath.Abs(root)
	if err != nil {
		return err
	}
	rel, err := filepath.Rel(base, filepath.Dir(target))
	if err != nil || rel == ".." || strings.HasPrefix(rel, ".."+string(filepath.Separator)) {
		return errors.New("Hedef kaynak klasörünün dışında")
	}
	cur := base
	for _, segment := range strings.Split(rel, string(filepath.Separator)) {
		if segment == "." || segment == "" {
			continue
		}
		cur = filepath.Join(cur, segment)
		if st, err := os.Lstat(cur); err == nil && st.Mode()&os.ModeSymlink != 0 {
			return errors.New("Sembolik bağlantılı klasöre dosya eklenemez")
		} else if err != nil && !os.IsNotExist(err) {
			return err
		}
	}
	return nil
}

func oneOf(s string, opts ...string) bool {
	for _, v := range opts {
		if s == v {
			return true
		}
	}
	return false
}

func maxInt64(a, b int64) int64 {
	if a > b {
		return a
	}
	return b
}
func downloadPackObject(ctx context.Context, p PackFile, dest string, progress func(int64)) error {
	var last error
	for attempt := 0; attempt < 3; attempt++ {
		if ctx.Err() != nil {
			return ctx.Err()
		}
		last = downloadVerifiedAsset(ctx, p.URL, p.AssetID, dest, p.SHA256, p.Size, progress)
		if last == nil {
			return nil
		}
		if attempt < 2 {
			select {
			case <-ctx.Done():
				return ctx.Err()
			case <-time.After(time.Duration(attempt+1) * time.Second):
			}
		}
	}
	return fmt.Errorf("3 denemede dosya indirilemedi: %w", last)
}
