package main

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"sort"
	"strings"
	"time"
)

// Health only checks files tracked by the AGALAR installer. User-created files are never touched.
type HealthReport struct {
	Version   string   `json:"version"`
	Checked   int      `json:"checked"`
	OK        int      `json:"ok"`
	Missing   []string `json:"missing"`
	Corrupted []string `json:"corrupted"`
}

func inspectInstallation(root string) (HealthReport, error) {
	report := HealthReport{Missing: []string{}, Corrupted: []string{}}
	if _, _, err := validateGameFolder(root); err != nil {
		return report, err
	}
	installed := readInstalled(root)
	report.Version = installed.Version
	if installed.Version == "" {
		return report, errors.New("Henüz AGALAR mod paketi kurulu değil")
	}
	for _, f := range installed.Files {
		report.Checked++
		path, err := localFilePath(root, f.Path)
		if err != nil {
			return report, err
		}
		if err = checkSourceParents(root, path); err != nil {
			return report, err
		}
		st, err := os.Lstat(path)
		if os.IsNotExist(err) {
			report.Missing = append(report.Missing, f.Path)
			continue
		}
		if err != nil {
			return report, err
		}
		if !st.Mode().IsRegular() {
			report.Corrupted = append(report.Corrupted, f.Path)
			continue
		}
		hash, _, err := shaFile(path)
		if err != nil {
			return report, err
		}
		if !strings.EqualFold(hash, f.SHA256) {
			report.Corrupted = append(report.Corrupted, f.Path)
		} else {
			report.OK++
		}
	}
	return report, nil
}

// Use the protocol registered by the official Minecraft Launcher; never silently run
// an unknown executable or claim to have started a particular modded game profile.
func openMinecraftLauncher() error {
	if runtime.GOOS != "windows" {
		return errors.New("Başlatıcı açma yalnızca Windows'ta kullanılabilir")
	}
	cmd := exec.Command("rundll32.exe", "url.dll,FileProtocolHandler", "minecraft://")
	if err := cmd.Start(); err != nil {
		return fmt.Errorf("Minecraft Launcher açılamadı: %w", err)
	}
	return nil
}

type CrashReport struct {
	File    string `json:"file"`
	Date    string `json:"date"`
	Preview string `json:"preview"`
	Kind    string `json:"kind"`
}

func recentCrash(root string) (CrashReport, error) {
	if _, _, err := validateGameFolder(root); err != nil {
		return CrashReport{}, err
	}
	candidates := []string{filepath.Join(root, "logs", "latest.log"), filepath.Join(root, "latest.log")}
	crashDir := filepath.Join(root, "crash-reports")
	entries, _ := os.ReadDir(crashDir)
	for _, d := range entries {
		if !d.IsDir() && strings.HasSuffix(strings.ToLower(d.Name()), ".txt") {
			candidates = append(candidates, filepath.Join(crashDir, d.Name()))
		}
	}
	type item struct {
		path  string
		mtime time.Time
		kind  string
	}
	var found []item
	for _, p := range candidates {
		st, err := os.Lstat(p)
		if err != nil || !st.Mode().IsRegular() {
			continue
		}
		kind := "Minecraft günlüğü"
		if strings.HasPrefix(p, crashDir+string(os.PathSeparator)) {
			kind = "Çökme raporu"
		}
		found = append(found, item{p, st.ModTime(), kind})
	}
	if len(found) == 0 {
		return CrashReport{}, errors.New("Bu Minecraft klasöründe günlük veya çökme raporu bulunamadı")
	}
	sort.Slice(found, func(i, j int) bool { return found[i].mtime.After(found[j].mtime) })
	latest := found[0]
	f, err := os.Open(latest.path)
	if err != nil {
		return CrashReport{}, err
	}
	defer f.Close()
	// Preview only last 24 KiB, not entire potentially huge logs.
	st, _ := f.Stat()
	start := st.Size() - 24576
	if start < 0 {
		start = 0
	}
	_, err = f.Seek(start, 0)
	if err != nil {
		return CrashReport{}, err
	}
	b := make([]byte, 24576)
	n, err := f.Read(b)
	if err != nil && !errors.Is(err, io.EOF) {
		return CrashReport{}, err
	}
	preview := string(b[:n])
	if start > 0 {
		if i := strings.IndexByte(preview, '\n'); i >= 0 {
			preview = preview[i+1:]
		}
	}
	return CrashReport{File: filepath.Base(latest.path), Date: latest.mtime.Format(time.RFC3339), Preview: preview, Kind: latest.kind}, nil
}

type PackHistory struct {
	Version string `json:"version"`
	Notes   string `json:"notes"`
	Tag     string `json:"tag"`
}

func publishedHistory(ctx context.Context) ([]PackHistory, error) {
	releases, err := listReleases(ctx)
	if err != nil {
		return nil, err
	}
	out := make([]PackHistory, 0)
	for _, rel := range releases {
		if rel.Draft || rel.Prerelease || !strings.HasPrefix(rel.Tag, "pack-v") {
			continue
		}
		if len(out) >= 15 {
			break
		}
		manifest, err := fetchPackManifest(ctx, rel)
		if err != nil {
			continue
		} // hide corrupted/unavailable release instead of making history unusable
		out = append(out, PackHistory{Version: manifest.Version, Notes: manifest.Notes, Tag: rel.Tag})
	}
	return out, nil
}

// A backup records the original installed manifest and the exact changed paths.
// It never contains saves/worlds, and cannot restore an arbitrary path.
type BackupRecord struct {
	Profile   string          `json:"profile"`
	Previous  Installed       `json:"previous"`
	Updated   Installed       `json:"updated"`
	Changed   []string        `json:"changed"`
	Saved     []InstalledFile `json:"saved"`
	CreatedAt string          `json:"created_at"`
}
type BackupSummary struct {
	ID     string `json:"id"`
	Before string `json:"before"`
	After  string `json:"after"`
	Count  int    `json:"count"`
	Date   string `json:"date"`
}

func backupRecords(profile string) ([]BackupSummary, error) {
	entries, err := os.ReadDir(filepath.Join(dataDir(), "backups"))
	if os.IsNotExist(err) {
		return []BackupSummary{}, nil
	}
	if err != nil {
		return nil, err
	}
	var out []BackupSummary
	for _, d := range entries {
		if !d.IsDir() {
			continue
		}
		b, err := os.ReadFile(filepath.Join(dataDir(), "backups", d.Name(), "agalar-backup.json"))
		if err != nil {
			continue
		}
		var r BackupRecord
		if json.Unmarshal(b, &r) != nil || !sameFolder(profile, r.Profile) {
			continue
		}
		out = append(out, BackupSummary{ID: d.Name(), Before: r.Previous.Version, After: r.Updated.Version, Count: len(r.Changed), Date: r.CreatedAt})
	}
	sort.Slice(out, func(i, j int) bool { return out[i].ID > out[j].ID })
	return out, nil
}
func sameFolder(a, b string) bool {
	a = filepath.Clean(a)
	b = filepath.Clean(b)
	if runtime.GOOS == "windows" {
		return strings.EqualFold(a, b)
	}
	return a == b
}

// This operation restores only when the current installation exactly matches
// the backup's post-update manifest. It will not overwrite a user's edits.
func restoreBackup(profile, id string) error {
	if id == "" || strings.ContainsAny(id, "/\\:") || id == "." || id == ".." {
		return errors.New("Geçersiz yedek seçimi")
	}
	if _, _, err := validateGameFolder(profile); err != nil {
		return err
	}
	folder := filepath.Join(dataDir(), "backups", id)
	b, err := os.ReadFile(filepath.Join(folder, "agalar-backup.json"))
	if err != nil {
		return err
	}
	var rec BackupRecord
	if err = json.Unmarshal(b, &rec); err != nil {
		return err
	}
	if !sameFolder(profile, rec.Profile) {
		return errors.New("Yedek farklı Minecraft profiline ait")
	}
	current := readInstalled(profile)
	if current.Version != rec.Updated.Version {
		return errors.New("Bu yedek yalnızca hemen sonraki paket sürümünden geri yüklenebilir")
	}
	// All changed files must be in exactly the state left by AGALAR.
	currentBytes, _ := json.Marshal(current)
	expectedBytes, _ := json.Marshal(rec.Updated)
	if string(currentBytes) != string(expectedBytes) {
		return errors.New("Kurulu paket kaydı yedekle eşleşmiyor")
	}
	newFiles := map[string]string{}
	oldFiles := map[string]string{}
	for _, f := range rec.Updated.Files {
		newFiles[f.Path] = f.SHA256
	}
	for _, f := range rec.Saved {
		oldFiles[f.Path] = f.SHA256
	}
	for _, f := range rec.Changed {
		path, err := localFilePath(profile, f)
		if err != nil {
			return err
		}
		if err = checkSourceParents(profile, path); err != nil {
			return err
		}
		expected, exists := newFiles[f]
		st, err := os.Lstat(path)
		if exists {
			if err != nil || !st.Mode().IsRegular() {
				return fmt.Errorf("%s artık değişmiş veya silinmiş; geri alma durduruldu", f)
			}
			hash, _, e := shaFile(path)
			if e != nil || !strings.EqualFold(hash, expected) {
				return fmt.Errorf("%s kullanıcı tarafından değiştirilmiş; geri alma durduruldu", f)
			}
		} else if err == nil {
			return fmt.Errorf("%s yeniden oluşturulmuş; geri alma durduruldu", f)
		} else if !os.IsNotExist(err) {
			return err
		}
		if _, hadOld := oldFiles[f]; hadOld {
			backupPath := filepath.Join(folder, filepath.FromSlash(f))
			hash, _, e := shaFile(backupPath)
			if e != nil || !strings.EqualFold(hash, oldFiles[f]) {
				return fmt.Errorf("%s yedeği yok veya bozuk", f)
			}
		}
	}
	// Stage backups and a pre-restore snapshot to recover even if a file operation fails.
	staging, err := os.MkdirTemp(filepath.Join(dataDir(), "backups"), ".restore-")
	if err != nil {
		return err
	}
	defer os.RemoveAll(staging)
	for _, f := range rec.Changed {
		if _, ok := newFiles[f]; ok {
			p, _ := localFilePath(profile, f)
			if err = fileCopy(filepath.Join(staging, filepath.FromSlash(f)), p); err != nil {
				return err
			}
		}
	}
	applied := []string{}
	rollback := func(cause error) error {
		var problems []string
		for i := len(applied) - 1; i >= 0; i-- {
			f := applied[i]
			path, _ := localFilePath(profile, f)
			if _, ok := newFiles[f]; ok {
				if e := fileCopy(path, filepath.Join(staging, filepath.FromSlash(f))); e != nil {
					problems = append(problems, f)
				}
			} else {
				if e := os.Remove(path); e != nil && !os.IsNotExist(e) {
					problems = append(problems, f)
				}
			}
		}
		if len(problems) > 0 {
			return fmt.Errorf("%w; geri alma kısmen başarısız: %s", cause, strings.Join(problems, ", "))
		}
		return cause
	}
	for _, f := range rec.Changed {
		path, _ := localFilePath(profile, f)
		if err = os.Remove(path); err != nil && !os.IsNotExist(err) {
			return rollback(err)
		}
		applied = append(applied, f)
		if _, ok := oldFiles[f]; ok {
			if err = fileCopy(path, filepath.Join(folder, filepath.FromSlash(f))); err != nil {
				return rollback(err)
			}
		}
	}
	if err = atomicJSON(installedPath(profile), rec.Previous); err != nil {
		return rollback(err)
	}
	return nil
}
