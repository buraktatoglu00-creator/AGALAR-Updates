# AGALAR Modpack Manager v1.4.0

**Minecraft:** Forge 1.20.1 / 47.4.10  
**Hedef:** Windows 10/11 (64-bit); mevcut tek `AGALAR.exe` korunur.  
**GitHub:** `buraktatoglu00-creator/AGALAR-Updates`

## v1.4.0 yenilikleri

- **Bakım & Sunucu** sekmesi, önceki arayüz ve bütün eski yönetici/oyuncu işlevleri korunarak eklendi.
- **Dosyaları Kontrol Et:** Bu profilde AGALAR tarafından kurulmuş dosyaların SHA-256 bütünlüğünü tarar. Eksik, bozuk ve sağlam dosya sayısını gösterir; kişisel dosyaları silmez.
- **Eksikleri Onar:** Zaten mevcut olan güvenli kurulum sistemini kullanarak yayımlanmış *en yeni* mod paketini indirir; gerekirse güncellemeyi de uygular. Oyun tamamen kapalı olmalıdır.
- **Minecraft Launcher'ı Aç:** Windows'un kayıtlı `minecraft://` protokolüne başvurarak resmî başlatıcıyı açmayı dener. Minecraft'ı veya özel Forge profilini doğrudan başlatmaz; **Forge 1.20.1 / 47.4.10** profilini başlatıcıdan seçmek gerekir. Launcher yüklü değilse düğme işe yaramayabilir; diğer başlatıcıların tümü desteklenmez.
- **Hata Teşhisi:** Seçilen oyun klasöründeki en son `crash-reports/*.txt` veya `logs/latest.log` dosyasının son en fazla 24 KiB kısmını gösterir ve istenirse panoya kopyalar. Loglar otomatik dışarı gönderilmez, ayrıca mod kaynaklı hatalara otomatik çözüm üretmez. Log paylaşmadan önce kişisel bilgileri ayıkla.
- **Paket Sürüm Geçmişi:** GitHub Releases içindeki yayımlanmış `pack-v*` sürümlerinin bildirim notlarını gösterir. Bozuk/geçersiz sürümler atlanır.
- **Kurulum yedekleri:** Bundan sonra paket kurma/güncellemede değişen dosyaların yedeklerinin yanında, önceki/yeni sürüm meta verisi saklanır. Bir işlem yedeğine yalnızca beklenen mevcut dosyalar değiştirilmemişse geri dönülür. İlk kurulumda varsa üzerine yazılmış eski kullanıcı dosyaları da korunur. **v1.3.x'teki eski yedekler otomatik geri almaya uygun değildir** ve mevcut dünya kayıtları hiçbir şekilde bu özelliğe dahil edilmez.
- **Exaroton hazırlığı:** Sunucu açmadan 3–5 kişi, hedef 4 GB ve en fazla 5 GB RAM planı gösterilir. Başlatma ve canlı durum bilerek kapalıdır; herhangi bir API anahtarı eklenmemiştir. Bu sürüm **sunucu oluşturmaz ve kredi harcamaz**.

## Eskiden kalan özellikler

- Tek `AGALAR.exe` içinde oyuncu ve yönetici görünümü; yönetici görünümü şu anda parolasızdır. GitHub'da yayın yapmak için kullanıcının kendi gizli erişim anahtarı gerekir.
- GitHub mod paketi yayınlama, otomatik sürüm numarası, içerik kütüphanesi, sürükle-bırak yükleme, ayar dosyaları, grafik profilleri ve data pack aktarımı.
- Uygulama içinden güncelleme, SHA-256 indirme doğrulaması, geçici klasör indirmesi, yedekleme ve başarısız dosya işlemlerinde geri alma.
- Exaroton için sunucu **ayarları** ZIP çıktısı; henüz tam sunucu mod paketi dışa aktarma veya Exaroton'a API ile aktarım yok.

## Sınırlar ve gelecek sürümler

- **v1.5.0:** Sunucu/istemci mod ayrımı, sunucu paketleme, 4–5 GB RAM hedefli öneriler.
- **v1.6.0:** Exaroton'a güvenli sunucu başlatma/durum sorgulama entegrasyonu. Arkadaşların EXE'sine yönetici API anahtarı kesinlikle gömülmeyecek; sunucu olmadan gerçek API entegrasyonu uçtan uca doğrulanamaz.
- **v2.0.0:** Son kullanıcı testleri, arayüz son düzenlemeleri ve dağıtım güvenliği.

## Derleme ve test

Go 1.22+ gerekir; harici Go bağımlılığı yoktur. Kaynak klasöründe:

```
go test ./...
go test -race ./...
go vet ./...
GOOS=windows GOARCH=amd64 CGO_ENABLED=0 go build -trimpath -ldflags='-H windowsgui -s -w' -o AGALAR.exe .
```

Kaynak ZIP'i `.github/workflows/release.yml` bulunan GitHub deposunun **kök dizinine** `AGALAR-Kaynak-v1.4.0.zip` adıyla yüklendiğinde iş akışı derlemeyi yapıp `app-v1.4.0` uygulama sürümünü oluşturabilir. Dosyayı GitHub'a yüklemek yerel bilgisayardaki `AGALAR.exe` uygulamasını doğrudan değiştirmez. Mevcut uygulamadaki **Uygulamayı Güncelle** düğmesiyle yeni sürüme geçilebilir.

### Test sınırları

Yerel Go testleri ve Windows hedefli derleme yapılmıştır; gerçek Windows Launcher açma, gerçek GitHub yayınlama ve Exaroton (henüz sunucu yok) bağlantısı burada canlı test edilmemiştir. Mod paketi ve dünya kayıtlarının bir yedeğini tutarak küçük bir paket üzerinde test etmek önerilir.
