package main

import (
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

func testGameFolder(t *testing.T) string {
	t.Helper()
	root := t.TempDir()
	if err := os.MkdirAll(filepath.Join(root, "mods"), 0700); err != nil {
		t.Fatal(err)
	}
	return root
}
func testSaveFile(t *testing.T, dir, name, content string) string {
	t.Helper()
	path := filepath.Join(dir, filepath.FromSlash(name))
	if err := os.MkdirAll(filepath.Dir(path), 0700); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(path, []byte(content), 0600); err != nil {
		t.Fatal(err)
	}
	return path
}
func TestHealthReportFindsMissingAndCorrupt(t *testing.T) {
	t.Setenv("XDG_CONFIG_HOME", t.TempDir())
	root := testGameFolder(t)
	testSaveFile(t, root, "mods/ok.jar", "fine")
	testSaveFile(t, root, "mods/broken.jar", "changed")
	installed := Installed{Version: "1.0.0", Files: []InstalledFile{{Path: "mods/ok.jar", SHA256: hashBytes([]byte("fine"))}, {Path: "mods/broken.jar", SHA256: hashBytes([]byte("expected"))}, {Path: "mods/missing.jar", SHA256: hashBytes([]byte("missing"))}}}
	if err := atomicJSON(installedPath(root), installed); err != nil {
		t.Fatal(err)
	}
	report, err := inspectInstallation(root)
	if err != nil {
		t.Fatal(err)
	}
	if report.Checked != 3 || report.OK != 1 || len(report.Missing) != 1 || len(report.Corrupted) != 1 {
		t.Fatalf("unexpected health report: %+v", report)
	}
}
func createTestBackup(t *testing.T) (root, id string) {
	t.Helper()
	t.Setenv("XDG_CONFIG_HOME", t.TempDir())
	root = testGameFolder(t)
	testSaveFile(t, root, "mods/existing.jar", "new data")
	testSaveFile(t, root, "mods/new.jar", "new file")
	updated := Installed{Version: "1.0.2", Files: []InstalledFile{{Path: "mods/existing.jar", SHA256: hashBytes([]byte("new data"))}, {Path: "mods/new.jar", SHA256: hashBytes([]byte("new file"))}}}
	if err := atomicJSON(installedPath(root), updated); err != nil {
		t.Fatal(err)
	}
	id = "20261020-000000.000000001"
	backupDir := filepath.Join(dataDir(), "backups", id)
	testSaveFile(t, backupDir, "mods/existing.jar", "original user data")
	record := BackupRecord{Profile: root, Previous: Installed{}, Updated: updated, Changed: []string{"mods/existing.jar", "mods/new.jar"}, Saved: []InstalledFile{{Path: "mods/existing.jar", SHA256: hashBytes([]byte("original user data"))}}, CreatedAt: time.Now().Format(time.RFC3339)}
	if err := atomicJSON(filepath.Join(backupDir, "agalar-backup.json"), record); err != nil {
		t.Fatal(err)
	}
	return root, id
}
func TestRestoreFirstInstallPreservesPreexistingFiles(t *testing.T) {
	root, id := createTestBackup(t)
	if err := restoreBackup(root, id); err != nil {
		t.Fatal(err)
	}
	b, err := os.ReadFile(filepath.Join(root, "mods", "existing.jar"))
	if err != nil {
		t.Fatal(err)
	}
	if string(b) != "original user data" {
		t.Fatalf("old user data lost: %s", b)
	}
	if _, err := os.Stat(filepath.Join(root, "mods", "new.jar")); !os.IsNotExist(err) {
		t.Fatal("new file should be removed")
	}
	if readInstalled(root).Version != "" {
		t.Fatal("expected pre-install metadata")
	}
}
func TestRestoreRejectsUserEditsWithoutChangingFiles(t *testing.T) {
	root, id := createTestBackup(t)
	testSaveFile(t, root, "mods/existing.jar", "user edited")
	err := restoreBackup(root, id)
	if err == nil || !strings.Contains(err.Error(), "kullanıcı") {
		t.Fatalf("expected user edit protection: %v", err)
	}
	b, _ := os.ReadFile(filepath.Join(root, "mods/existing.jar"))
	if string(b) != "user edited" {
		t.Fatal("user edit was changed")
	}
	b, _ = os.ReadFile(filepath.Join(root, "mods/new.jar"))
	if string(b) != "new file" {
		t.Fatal("other file was changed")
	}
}
func TestBackupListAndTraversalBlocked(t *testing.T) {
	root, id := createTestBackup(t)
	backups, err := backupRecords(root)
	if err != nil {
		t.Fatal(err)
	}
	if len(backups) != 1 || backups[0].ID != id {
		t.Fatalf("unexpected backups: %+v", backups)
	}
	if err = restoreBackup(root, "../secret"); err == nil {
		t.Fatal("path traversal accepted")
	}
}
