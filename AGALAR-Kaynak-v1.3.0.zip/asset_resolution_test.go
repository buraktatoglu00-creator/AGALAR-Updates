package main

import (
	"bytes"
	"context"
	"encoding/json"
	"io"
	"net/http"
	"strings"
	"testing"
)

func TestResolvePackAssetsReplacesStaleManifestURL(t *testing.T) {
	hash := strings.Repeat("a", 64)
	stale := "https://github.com/" + githubOwner + "/" + githubRepo + "/releases/download/pack-v0.9.0/obj-" + hash
	valid := "https://github.com/" + githubOwner + "/" + githubRepo + "/releases/download/pack-v1.0.0/obj-" + hash
	rel := GHRelease{Tag: "pack-v1.0.0", Assets: []ReleaseAsset{{Name: "obj-" + hash, Size: 12, URL: valid}}}
	b, _ := json.Marshal([]GHRelease{rel})
	prev := apiClient
	defer func() { apiClient = prev }()
	apiClient = &http.Client{Transport: roundTrip(func(req *http.Request) (*http.Response, error) {
		return &http.Response{StatusCode: 200, Body: io.NopCloser(bytes.NewReader(b)), Header: make(http.Header), Request: req}, nil
	})}
	got, err := resolvePackAssets(context.Background(), rel, []PackFile{{Path: "mods/a.jar", SHA256: hash, Size: 12, URL: stale}})
	if err != nil || got[0].URL != valid {
		t.Fatalf("got %#v, err %v", got, err)
	}
}

func TestResolvePackAssetsFailsBeforeInstallingMissingFile(t *testing.T) {
	rel := GHRelease{Tag: "pack-v1.0.0"}
	b, _ := json.Marshal([]GHRelease{rel})
	prev := apiClient
	defer func() { apiClient = prev }()
	apiClient = &http.Client{Transport: roundTrip(func(req *http.Request) (*http.Response, error) {
		return &http.Response{StatusCode: 200, Body: io.NopCloser(bytes.NewReader(b)), Header: make(http.Header), Request: req}, nil
	})}
	_, err := resolvePackAssets(context.Background(), rel, []PackFile{{Path: "mods/a.jar", SHA256: strings.Repeat("a", 64), Size: 12}})
	if err == nil || !strings.Contains(err.Error(), "GitHub'da dosya eksik") {
		t.Fatalf("unexpected error %v", err)
	}
}
