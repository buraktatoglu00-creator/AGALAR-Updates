# AGALAR Modpack Manager 1.3.0 — tek Windows uygulaması

**Hedef:** Windows 10/11 (64-bit), Minecraft 1.20.1, Forge 47.4.10. İndirme ve yayınlar `buraktatoglu00-creator/AGALAR-Updates` deposundan alınır. Yalnızca `AGALAR.exe` gerekir; eski `AGALAR-Admin.exe` artık kullanılmaz.

## Uygulama

- Sol üstten **Yönetici Paneline Geç** / **Oyuncu Paneline Geç** ile aynı EXE'de geçiş yapılır. İsteğin doğrultusunda henüz yönetici parolası konulmadı. **Uygulamayı başka kişilere verdiğinde yönetici menüsü de görülebilir**; GitHub'da yayınlamak için ise erişim anahtarı gerekir.
- **Oyuncu:** Tek ana düğme **Mod Paketini Kur / Güncelle**. Bilinen Minecraft profili otomatik seçilir; birden fazla profil varsa doğru oyun klasörünü gelişmiş seçeneklerden bir kez seçmek gerekir. Forge 47.4.10, standart oyun klasöründeki `versions` dizininde eksikse resmî Forge yükleyicisi otomatik denenir. Bunun için Java'nın kullanılabilir olması gerekir. CurseForge gibi Forge'u ayrı yöneten başlatıcılarda Forge sürümünü başlatıcın yönetir. Minecraft'ın hiç kurulmadığı bir bilgisayara Minecraft Launcher/oyun kurulumu yapılmaz.
- **Yönetici:** İçerik kütüphanesinde modlar, kaynak paketleri, shaderlar, data packler, config, defaultconfigs, KubeJS ve scriptler. Dosya seçme, klasör seçme, sürükle-bırak, dosya kaldırma (yedekli), config düzenleme, grafik profilleri, sürüm farkları ve Exaroton için sunucu config ZIP'i özellikleri korunur.
- **Yayınla:** Yüklenen mod paketindeki değişiklikler yayınlama öncesi karşılaştırılır; paket sürümü bir artırılarak hazırlanır. GitHub anahtarı **Yönetici → GitHub erişim anahtarı ayarları** bölümünden bir kez girilir. Anahtar Windows kullanıcısı için DPAPI ile şifrelenir, GitHub'a yayınlamak dışında arkadaşlarla paylaşılmaz.
- **İlerleme/bildirimler:** Ekranın sağ alt köşesinde yüzde ve uygun olduğunda tahmini kalan süre; başarı bildirimi alttaki turuncu çubuk 7 saniyede dolunca kaybolur. Bildirimde geri sayım metni yer almaz. Hatalar otomatik kaybolmaz. Yönetici panelinde işlem geçmişi bulunur.
- **Güncelleyici:** GitHub'da `app-v1.3.1` gibi daha yeni bir uygulama sürümü `AGALAR.exe` ve `app-manifest.json` dosyalarıyla yayınlandığında **Uygulamayı Güncelle** düğmesi aktif olur. Yeni dosya SHA-256 ile doğrulanıp uygulama tekrar açılır; `.previous` yedeği kalır. İlk defa 1.3.0'a geçerken yeni tek EXE'nin bir kez kurulması gerekir.

## Dosyaları koruma

Mod paketi önce geçici klasöre indirilir ve SHA-256 ile kontrol edilir. İndirme başarısızsa oyuna dosya yazılmaz. İndirilen dosyalar doğrulandıktan sonra değişen dosyalar yedeklenir; uygulanırken hata olursa mevcut dosyalar geri yüklenmeye çalışılır. Mod yöneticisi dünyalara (`saves`) dokunmaz. Data packleri mevcut dünyalara uygulamak **ayrı onay** gerektirir. Kullanıcı tarafından değiştirilmiş, yöneticinin artık takip etmediği dosyalar otomatik silinmez.

## GitHub yayınlama / kalıcı uygulama güncelleme

Depodaki `.github/workflows/release.yml` iş akışı yeni kaynak ZIP'i `main` dalına eklenince Windows EXE üretir ve `app-v{version}` sürümünü GitHub Releases bölümüne yayınlar. **Bu sürümün GitHub'a eklenmesi için** `AGALAR-Kaynak-v1.3.0.zip` dosyasının depo köküne yüklenmesi gerekir. Yalnızca sohbetten indirilmiş yerel EXE GitHub'da güncelleme olarak kendiliğinden yayınlanmaz. Yayınlanan sürümler yeni uygulamalarda algılanır. Sonraki sürümlerde uygulama içi güncelleyici kullanılabilir.

Bu paket GitHub'da yayımlanmış gibi gösterilmez; ancak `.github/workflows/release.yml` iş akışıyla yayımlanabilir. GitHub sürüm dosyalarının gerçek Windows makinede indirilmesi ve Forge'un ilk kurulumu burada doğrulanamadı.

## Kod ve test

Go 1.22+; harici Go kütüphanesi yok. `go test ./...`, `go test -race ./...`, `go vet ./...`. Windows derleme:

```
GOOS=windows GOARCH=amd64 CGO_ENABLED=0 go build -trimpath -ldflags="-s -w -H windowsgui" -o AGALAR.exe .
```

Başka üretim dosyasına gerek yok; `ui.html` EXE içine gömülür. Çalışmak için Edge veya Chrome gerekir.

## Dürüst test sınırları

Otomatik testlerde GitHub HTTP 404 → resmî Asset API indirme alternatifi, bozuk ikinci mod → kuruluma başlamadan durma, eski dosyaların ve dünyanın korunması, sürüm karşılaştırması, içerik/yükleme güvenliği ve yönetici/oyuncu geçişi kontrol edildi. Linux üzerinde Go testleri ve Windows hedefli derleme geçti. **Windows 10/11 üzerinde gerçek EXE, Forge Installer ve GitHub'a gerçek paket yayınlama uçtan uca doğrulanmadı.** Bu ortamda tüm olası hataların kalmadığını garanti etmek mümkün değildir. Gerçek yayınlamadan önce küçük bir test mod paketiyle dene.
