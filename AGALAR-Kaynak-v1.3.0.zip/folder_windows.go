//go:build windows

package main

import (
	"errors"
	"runtime"
	"syscall"
	"unsafe"
)

type browseInfo struct {
	Owner    uintptr
	Root     uintptr
	Display  *uint16
	Title    *uint16
	Flags    uint32
	Callback uintptr
	Param    uintptr
	Image    int32
}

var shell32 = syscall.NewLazyDLL("shell32.dll")
var ole32 = syscall.NewLazyDLL("ole32.dll")
var folderBrowse = shell32.NewProc("SHBrowseForFolderW")
var folderPath = shell32.NewProc("SHGetPathFromIDListW")
var comFree = ole32.NewProc("CoTaskMemFree")
var coInitialize = ole32.NewProc("CoInitializeEx")
var coUninitialize = ole32.NewProc("CoUninitialize")

func nativeChooseFolder() (string, error) {
	runtime.LockOSThread()
	defer runtime.UnlockOSThread()
	hr, _, _ := coInitialize.Call(0, 2) // COINIT_APARTMENTTHREADED
	if hr == 0 || hr == 1 {
		defer coUninitialize.Call()
	}
	title, _ := syscall.UTF16PtrFromString("AGALAR - Klasör seç")
	name := make([]uint16, 260)
	info := browseInfo{Display: &name[0], Title: title, Flags: 0x1 | 0x40} // filesystem folders, new UI
	id, _, _ := folderBrowse.Call(uintptr(unsafe.Pointer(&info)))
	if id == 0 {
		return "", errors.New("Klasör seçimi iptal edildi")
	}
	defer comFree.Call(id)
	buf := make([]uint16, 32768)
	ok, _, _ := folderPath.Call(id, uintptr(unsafe.Pointer(&buf[0])))
	if ok == 0 {
		return "", errors.New("Klasör yolu okunamadı")
	}
	return syscall.UTF16ToString(buf), nil
}
