package main

import (
	"fmt"
	"strconv"
	"strings"
)

func nextPackVersion(current string) string {
	if strings.TrimSpace(current) == "" {
		return "1.0.0"
	}
	parts := strings.Split(current, ".")
	if len(parts) != 3 {
		return "1.0.0"
	}
	patch, err := strconv.Atoi(parts[2])
	if err != nil || patch < 0 || patch >= 999999 {
		return "1.0.0"
	}
	return fmt.Sprintf("%s.%s.%d", parts[0], parts[1], patch+1)
}

// If several game directories exist, don't guess and risk writing to the wrong one.
func autoInstallProfile() (string, bool) {
	profiles := detectMinecraftProfiles("")
	if len(profiles) == 1 {
		return profiles[0].Path, true
	}
	return "", false
}
