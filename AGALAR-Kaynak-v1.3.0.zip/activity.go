package main

import (
	"bufio"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"time"
)

var activityLogLock sync.Mutex

func activityLogPath() string { return filepath.Join(dataDir(), "logs", "activity.log") }
func writeActivityLog(level, message string) {
	activityLogLock.Lock()
	defer activityLogLock.Unlock()
	path := activityLogPath()
	if err := os.MkdirAll(filepath.Dir(path), 0700); err != nil {
		return
	}
	if st, err := os.Stat(path); err == nil && st.Size() > 2<<20 {
		_ = os.Rename(path, path+".previous")
	}
	message = strings.ReplaceAll(strings.ReplaceAll(message, "\r", " "), "\n", " ")
	if len(message) > 700 {
		message = message[:700] + "..."
	}
	f, err := os.OpenFile(path, os.O_WRONLY|os.O_APPEND|os.O_CREATE, 0600)
	if err != nil {
		return
	}
	defer f.Close()
	_, _ = f.WriteString(time.Now().Format("2006-01-02 15:04:05") + " | " + level + " | " + message + "\n")
}
func readActivityLog(limit int) ([]string, error) {
	activityLogLock.Lock()
	defer activityLogLock.Unlock()
	f, err := os.Open(activityLogPath())
	if os.IsNotExist(err) {
		return []string{}, nil
	}
	if err != nil {
		return nil, err
	}
	defer f.Close()
	scanner := bufio.NewScanner(f)
	scanner.Buffer(make([]byte, 4096), 8192)
	var lines []string
	for scanner.Scan() {
		lines = append(lines, scanner.Text())
		if len(lines) > limit {
			lines = lines[1:]
		}
	}
	return lines, scanner.Err()
}
