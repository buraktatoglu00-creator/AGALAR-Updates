//go:build !windows

package main

import "errors"

func nativeChooseFolder() (string, error) {
	return "", errors.New("Klasör seçici yalnızca Windows'ta kullanılabilir")
}
