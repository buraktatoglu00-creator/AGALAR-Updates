module github.com/buraktatoglu00-creator/agalar-manager

go 1.22
