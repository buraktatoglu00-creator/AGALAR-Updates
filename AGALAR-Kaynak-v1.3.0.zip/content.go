package main

import (
	"context"
	"encoding/json"
	"errors"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"time"
)

// ContentItem describes either a locally staged file or a published release asset.
type ContentItem struct {
	Path      string `json:"path"`
	Category  string `json:"category"`
	Size      int64  `json:"size"`
	SHA256    string `json:"sha256,omitempty"`
	Installed bool   `json:"installed"`
	Modified  bool   `json:"modified,omitempty"`
}

func contentCategory(path string) string {
	parts := strings.SplitN(strings.ReplaceAll(path, "\\", "/"), "/", 2)
	if len(parts) < 2 || !categories[parts[0]] {
		return ""
	}
	return parts[0]
}

func sourceContents(source string) ([]ContentItem, error) {
	items, err := scanSource(source)
	if err != nil {
		return nil, err
	}
	out := make([]ContentItem, 0, len(items))
	for _, f := range items {
		out = append(out, ContentItem{Path: f.Path, Category: contentCategory(f.Path), Size: f.Size})
	}
	return out, nil
}

func publishedContents(ctx context.Context, profile string) ([]ContentItem, string, error) {
	r, ok, err := newestRelease(ctx, "pack-v")
	if err != nil {
		return nil, "", err
	}
	if !ok {
		return []ContentItem{}, "", nil
	}
	manifest, err := fetchPackManifest(ctx, r)
	if err != nil {
		return nil, "", err
	}
	installed := readInstalled(profile)
	installedMap := make(map[string]string, len(installed.Files))
	for _, f := range installed.Files {
		installedMap[f.Path] = f.SHA256
	}
	out := make([]ContentItem, 0, len(manifest.Files))
	for _, f := range manifest.Files {
		match := strings.EqualFold(installedMap[f.Path], f.SHA256)
		item := ContentItem{Path: f.Path, Category: contentCategory(f.Path), Size: f.Size, SHA256: f.SHA256, Installed: match}
		if match && profile != "" {
			if digest, _, e := shaFile(filepath.Join(profile, filepath.FromSlash(f.Path))); e != nil || !strings.EqualFold(digest, f.SHA256) {
				item.Installed = false
				item.Modified = e == nil
			}
		}
		out = append(out, item)
	}
	return out, manifest.Version, nil
}

func isTextConfig(path string) bool {
	category := contentCategory(path)
	if category != "config" && category != "defaultconfigs" && category != "kubejs" && category != "scripts" {
		return false
	}
	switch strings.ToLower(filepath.Ext(path)) {
	case ".toml", ".json", ".json5", ".cfg", ".properties", ".txt", ".conf", ".js", ".zs", ".mcmeta", ".snbt", ".yaml", ".yml":
		return true
	}
	return false
}

func readSourceConfig(source, rel string) (string, error) {
	if !isTextConfig(rel) {
		return "", errors.New("Yalnızca metin yapılandırma dosyaları düzenlenebilir")
	}
	path, e := localFilePath(source, rel)
	if e != nil {
		return "", e
	}
	st, e := os.Lstat(path)
	if e != nil {
		return "", e
	}
	if !st.Mode().IsRegular() || st.Size() > 1<<20 {
		return "", errors.New("Dosya türü veya boyutu desteklenmiyor (en fazla 1 MB)")
	}
	b, e := os.ReadFile(path)
	if e != nil {
		return "", e
	}
	if strings.ContainsRune(string(b), 0) {
		return "", errors.New("İkili dosya düzenlenemez")
	}
	return string(b), nil
}

func saveSourceConfig(source, rel, content string) error {
	if !isTextConfig(rel) {
		return errors.New("Yalnızca metin yapılandırmaları kaydedilebilir")
	}
	if len(content) > 1<<20 || strings.ContainsRune(content, 0) {
		return errors.New("Dosya boyutu veya içeriği geçersiz")
	}
	if strings.EqualFold(filepath.Ext(rel), ".json") || strings.EqualFold(filepath.Ext(rel), ".mcmeta") {
		if !json.Valid([]byte(content)) {
			return errors.New("JSON biçimi geçersiz; dosya kaydedilmedi")
		}
	}
	path, e := localFilePath(source, rel)
	if e != nil {
		return e
	}
	if _, e = readSourceConfig(source, rel); e != nil {
		return e
	}
	backup := filepath.Join(source, ".agalar-trash", time.Now().UTC().Format("20060102-150405.000000000"), filepath.FromSlash(rel))
	if e = fileCopy(backup, path); e != nil {
		return e
	}
	return atomicBytes(path, []byte(content))
}

type DiffEntry struct {
	Path string `json:"path"`
	Kind string `json:"kind"`
}
type PackDiff struct {
	Published string      `json:"published"`
	Added     int         `json:"added"`
	Changed   int         `json:"changed"`
	Removed   int         `json:"removed"`
	Same      int         `json:"same"`
	Entries   []DiffEntry `json:"entries"`
}

func compareSourceToPublished(ctx context.Context, source string) (PackDiff, error) {
	var result PackDiff
	if source == "" {
		return result, errors.New("Önce kaynak klasörünü seç")
	}
	local, e := scanSource(source)
	if e != nil {
		return result, e
	}
	release, found, e := newestRelease(ctx, "pack-v")
	if e != nil {
		return result, e
	}
	old := map[string]PackFile{}
	if found {
		pack, err := fetchPackManifest(ctx, release)
		if err != nil {
			return result, err
		}
		result.Published = pack.Version
		for _, f := range pack.Files {
			old[f.Path] = f
		}
	}
	for _, item := range local {
		f, exists := old[item.Path]
		if !exists {
			result.Added++
			result.Entries = append(result.Entries, DiffEntry{item.Path, "added"})
		} else {
			hash, size, err := shaFile(filepath.Join(source, filepath.FromSlash(item.Path)))
			if err != nil {
				return result, err
			}
			if size == f.Size && strings.EqualFold(hash, f.SHA256) {
				result.Same++
			} else {
				result.Changed++
				result.Entries = append(result.Entries, DiffEntry{item.Path, "changed"})
			}
			delete(old, item.Path)
		}
	}
	keys := make([]string, 0, len(old))
	for path := range old {
		keys = append(keys, path)
	}
	sort.Strings(keys)
	for _, path := range keys {
		result.Removed++
		result.Entries = append(result.Entries, DiffEntry{path, "removed"})
	}
	return result, nil
}
