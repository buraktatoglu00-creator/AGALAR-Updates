//go:build !windows

package main

import "errors"

func hasSavedToken() bool             { return false }
func saveToken(string) error          { return errors.New("Anahtar saklama Windows üzerinde kullanılabilir") }
func loadSavedToken() (string, error) { return "", nil }
func deleteSavedToken() error         { return nil }
