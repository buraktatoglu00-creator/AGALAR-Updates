package main

import (
	"bytes"
	"context"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

type tripFunc func(*http.Request) (*http.Response, error)

func (fn tripFunc) RoundTrip(r *http.Request) (*http.Response, error) { return fn(r) }
func fakeResp(code int, data []byte) *http.Response {
	return &http.Response{StatusCode: code, Body: io.NopCloser(bytes.NewReader(data)), Header: make(http.Header)}
}
func TestGitHubAssetAPIFallback(t *testing.T) {
	old := transferClient
	defer func() { transferClient = old }()
	payload := []byte("valid asset")
	sha := sha256.Sum256(payload)
	transferClient = &http.Client{Transport: tripFunc(func(r *http.Request) (*http.Response, error) {
		if r.URL.Host == "github.com" {
			return fakeResp(404, nil), nil
		}
		if r.URL.Host == "api.github.com" && strings.HasSuffix(r.URL.Path, "/releases/assets/51") {
			return fakeResp(200, payload), nil
		}
		return fakeResp(500, nil), nil
	})}
	target := filepath.Join(t.TempDir(), "obj")
	url := "https://github.com/buraktatoglu00-creator/AGALAR-Updates/releases/download/pack-v1.0.0/obj-test"
	if err := downloadVerifiedAsset(context.Background(), url, 51, target, hex.EncodeToString(sha[:]), int64(len(payload)), nil); err != nil {
		t.Fatal(err)
	}
	got, _ := os.ReadFile(target)
	if !bytes.Equal(got, payload) {
		t.Fatal("fallback payload mismatch")
	}
}
func TestInstallerLeavesGameUnchangedIfSecondFileFails(t *testing.T) {
	t.Setenv("XDG_CONFIG_HOME", t.TempDir())
	root := t.TempDir()
	if err := os.MkdirAll(filepath.Join(root, "mods"), 0700); err != nil {
		t.Fatal(err)
	}
	original := []byte("old-game-file")
	os.WriteFile(filepath.Join(root, "mods", "original.jar"), original, 0600)
	os.MkdirAll(filepath.Join(root, "saves", "My World"), 0700)
	os.WriteFile(filepath.Join(root, "saves", "My World", "level.dat"), []byte("world-data"), 0600)
	files := map[string][]byte{"mods/first.jar": []byte("first-good"), "mods/second.jar": []byte("second-good")}
	var manifest PackManifest
	manifest.Version = "1.0.0"
	manifest.Minecraft = minecraftVersion
	manifest.Forge = forgeVersion
	objects := make(map[string][]byte)
	for path, content := range files {
		sum := sha256.Sum256(content)
		hash := hex.EncodeToString(sum[:])
		name := "obj-" + hash
		objects[name] = content
		manifest.Files = append(manifest.Files, PackFile{Path: path, Size: int64(len(content)), SHA256: hash, URL: fmt.Sprintf("https://github.com/%s/%s/releases/download/pack-v1.0.0/%s", githubOwner, githubRepo, name)})
	}
	manifestBytes, _ := json.Marshal(manifest)
	release := GHRelease{Tag: "pack-v1.0.0", Assets: []ReleaseAsset{{Name: "pack-manifest.json", URL: fmt.Sprintf("https://github.com/%s/%s/releases/download/pack-v1.0.0/pack-manifest.json", githubOwner, githubRepo), Size: int64(len(manifestBytes))}}}
	for i, f := range manifest.Files {
		release.Assets = append(release.Assets, ReleaseAsset{ID: int64(i + 40), Name: "obj-" + f.SHA256, Size: f.Size, URL: f.URL})
	}
	releaseBytes, _ := json.Marshal([]GHRelease{release})
	oldApi, oldTransfer := apiClient, transferClient
	defer func() { apiClient = oldApi; transferClient = oldTransfer }()
	apiClient = &http.Client{Transport: tripFunc(func(r *http.Request) (*http.Response, error) { return fakeResp(200, releaseBytes), nil })}
	broken := true
	transferClient = &http.Client{Transport: tripFunc(func(r *http.Request) (*http.Response, error) {
		name := filepath.Base(r.URL.Path)
		if name == "pack-manifest.json" {
			return fakeResp(200, manifestBytes), nil
		}
		data, ok := objects[name]
		if !ok {
			return fakeResp(404, nil), nil
		}
		if broken && bytes.Equal(data, files["mods/second.jar"]) {
			data = []byte("second-bad!")
		}
		return fakeResp(200, data), nil
	})}
	app := &App{cfg: Config{Profile: root}, token: "unit-test", launched: time.Now(), lastRequest: time.Now()}
	if e := app.installPack(); e == nil {
		t.Fatal("corrupt download must fail")
	}
	if _, e := os.Stat(filepath.Join(root, "mods", "first.jar")); !os.IsNotExist(e) {
		t.Fatal("partially installed first jar")
	}
	got, _ := os.ReadFile(filepath.Join(root, "mods", "original.jar"))
	if !bytes.Equal(got, original) {
		t.Fatal("original changed")
	}
	got, _ = os.ReadFile(filepath.Join(root, "saves", "My World", "level.dat"))
	if string(got) != "world-data" {
		t.Fatal("world modified")
	}
	broken = false
	if e := app.installPack(); e != nil {
		t.Fatal(e)
	}
	for name, content := range files {
		got, e := os.ReadFile(filepath.Join(root, filepath.FromSlash(name)))
		if e != nil || !bytes.Equal(got, content) {
			t.Fatal(name, e)
		}
	}
	if readInstalled(root).Version != "1.0.0" {
		t.Fatal("installed version missing")
	}
}
func TestNextPackVersion(t *testing.T) {
	for _, v := range []struct{ in, out string }{{"", "1.0.0"}, {"1.0.0", "1.0.1"}, {"1.0.9", "1.0.10"}, {"2.3.99", "2.3.100"}} {
		if got := nextPackVersion(v.in); got != v.out {
			t.Fatalf("%s => %s", v.in, got)
		}
	}
}
