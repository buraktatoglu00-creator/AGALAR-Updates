package main

import (
	"archive/zip"
	"errors"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"strings"
)

// Exports only shared configs/scripts; selecting which mods are server-side remains an administrator decision.
func exportServerConfigs(source, target string) (int, error) {
	if source == "" {
		return 0, errors.New("Önce kaynak klasörünü seç")
	}
	items, e := scanSource(source)
	if e != nil {
		return 0, e
	}
	if len(items) == 0 {
		return 0, errors.New("Dışa aktarılacak içerik bulunamadı")
	}
	if strings.TrimSpace(target) == "" {
		return 0, errors.New("ZIP hedefini seç")
	}
	if !strings.EqualFold(filepath.Ext(target), ".zip") {
		return 0, errors.New("Çıktı .zip olmalı")
	}
	if e = os.MkdirAll(filepath.Dir(target), 0700); e != nil {
		return 0, e
	}
	temp, e := os.CreateTemp(filepath.Dir(target), ".agalar-server-*.zip")
	if e != nil {
		return 0, e
	}
	defer os.Remove(temp.Name())
	zw := zip.NewWriter(temp)
	count := 0
	for _, item := range items {
		category := contentCategory(item.Path)
		if category != "config" && category != "defaultconfigs" && category != "kubejs" && category != "scripts" {
			continue
		}
		low := strings.ToLower(strings.ReplaceAll(item.Path, "\\", "/"))
		// Client-only configs and KubeJS client assets do not belong in an Exaroton archive.
		if strings.Contains(low, "/client_scripts/") || strings.HasSuffix(low, "-client.toml") || strings.HasSuffix(low, "_client.toml") || strings.HasPrefix(low, "kubejs/assets/") {
			continue
		}
		full := filepath.Join(source, filepath.FromSlash(item.Path))
		f, e := os.Open(full)
		if e != nil {
			zw.Close()
			temp.Close()
			return 0, e
		}
		writer, e := zw.Create(item.Path)
		if e != nil {
			f.Close()
			zw.Close()
			temp.Close()
			return 0, e
		}
		_, e = io.Copy(writer, f)
		f.Close()
		if e != nil {
			zw.Close()
			temp.Close()
			return 0, e
		}
		count++
	}
	if e = zw.Close(); e != nil {
		temp.Close()
		return 0, e
	}
	if e = temp.Close(); e != nil {
		return 0, e
	}
	if count == 0 {
		return 0, errors.New("Sunucuya aktarılabilecek ortak ayar dosyası yok")
	}
	if _, e = os.Stat(target); e == nil {
		return 0, fmt.Errorf("%s zaten var; üzerine yazılmadı", target)
	}
	if e = os.Rename(temp.Name(), target); e != nil {
		return 0, e
	}
	return count, nil
}
