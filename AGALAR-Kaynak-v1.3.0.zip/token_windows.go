//go:build windows

package main

import (
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"syscall"
	"unsafe"
)

// Credentials are tied to the current Windows user via DPAPI (not embedded in EXE).
type dpapiBlob struct {
	Size uint32
	Data *byte
}

var crypt32 = syscall.NewLazyDLL("crypt32.dll")
var kernel32 = syscall.NewLazyDLL("kernel32.dll")
var protectData = crypt32.NewProc("CryptProtectData")
var unprotectData = crypt32.NewProc("CryptUnprotectData")
var localFree = kernel32.NewProc("LocalFree")

func githubTokenPath() string { return filepath.Join(dataDir(), "github-credential.dpapi") }
func hasSavedToken() bool     { s, e := os.Stat(githubTokenPath()); return e == nil && s.Size() > 0 }
func cryptToken(raw []byte, protect bool) ([]byte, error) {
	if len(raw) == 0 {
		return nil, errors.New("Boş anahtar")
	}
	in := dpapiBlob{Size: uint32(len(raw)), Data: &raw[0]}
	var out dpapiBlob
	var ret uintptr
	var callErr error
	if protect {
		ret, _, callErr = protectData.Call(uintptr(unsafe.Pointer(&in)), 0, 0, 0, 0, 0, uintptr(unsafe.Pointer(&out)))
	} else {
		ret, _, callErr = unprotectData.Call(uintptr(unsafe.Pointer(&in)), 0, 0, 0, 0, 0, uintptr(unsafe.Pointer(&out)))
	}
	if ret == 0 {
		return nil, fmt.Errorf("Windows kimlik bilgisi korunamadı/okunamadı: %v", callErr)
	}
	defer localFree.Call(uintptr(unsafe.Pointer(out.Data)))
	return append([]byte(nil), unsafe.Slice(out.Data, out.Size)...), nil
}
func saveToken(s string) error {
	if !strings.HasPrefix(s, "github_pat_") && !strings.HasPrefix(s, "ghp_") {
		return errors.New("Geçerli GitHub erişim anahtarını gir")
	}
	b, e := cryptToken([]byte(s), true)
	if e != nil {
		return e
	}
	return atomicBytes(githubTokenPath(), b)
}
func loadSavedToken() (string, error) {
	b, e := os.ReadFile(githubTokenPath())
	if os.IsNotExist(e) {
		return "", nil
	}
	if e != nil {
		return "", e
	}
	plain, e := cryptToken(b, false)
	if e != nil {
		return "", e
	}
	return string(plain), nil
}
func deleteSavedToken() error {
	e := os.Remove(githubTokenPath())
	if os.IsNotExist(e) {
		return nil
	}
	return e
}
