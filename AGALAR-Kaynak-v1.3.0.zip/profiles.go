package main

import (
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"runtime"
	"sort"
	"strings"
)

// ProfileCandidate is a local Minecraft *game directory* (not the launcher installation directory).
// We deliberately only scan a short list of conventional user directories.
type ProfileCandidate struct {
	Name    string `json:"name"`
	Path    string `json:"path"`
	Source  string `json:"source"`
	Details string `json:"details"`
}

func canonicalFolder(raw string) (string, error) {
	raw = strings.Trim(strings.TrimSpace(raw), `"`)
	if raw == "" {
		return "", errors.New("Klasör yolu boş")
	}
	abs, err := filepath.Abs(os.ExpandEnv(raw))
	if err != nil {
		return "", fmt.Errorf("Klasör yolu geçersiz: %w", err)
	}
	info, err := os.Stat(abs)
	if err != nil {
		return "", fmt.Errorf("Klasör bulunamadı: %w", err)
	}
	if !info.IsDir() {
		return "", errors.New("Girilen yol bir klasör değil")
	}
	return filepath.Clean(abs), nil
}

func existsFile(p string) bool {
	st, err := os.Stat(p)
	return err == nil && st.Mode().IsRegular()
}
func existsDirectory(p string) bool {
	st, err := os.Stat(p)
	return err == nil && st.IsDir()
}

func minecraftMarkers(root string) []string {
	markers := []struct {
		path, label string
		dir         bool
	}{
		{"options.txt", "Oyun ayarları", false},
		{"minecraftinstance.json", "CurseForge profili", false},
		{"launcher_profiles.json", "Minecraft Launcher", false},
		{"versions", "Oyun sürümleri", true},
		{"mods", "Mod klasörü", true},
		{"config", "Mod ayarları", true},
		{"saves", "Dünyalar", true},
	}
	var found []string
	for _, marker := range markers {
		p := filepath.Join(root, marker.path)
		if (marker.dir && existsDirectory(p)) || (!marker.dir && existsFile(p)) {
			found = append(found, marker.label)
		}
	}
	return found
}

// validateGameFolder fails closed: it will not write a modpack into an arbitrary folder.
func validateGameFolder(input string) (string, string, error) {
	path, err := canonicalFolder(input)
	if err != nil {
		return "", "", err
	}
	markers := minecraftMarkers(path)
	if len(markers) == 0 {
		return "", "", errors.New("Bu klasör Minecraft oyun klasörüne benzemiyor. TLauncher'da Ayarlar → Minecraft klasörü yolunu kontrol et (options.txt veya mods klasörü bulunamadı)")
	}
	return path, strings.Join(markers, " · "), nil
}

func detectMinecraftProfiles(current string) []ProfileCandidate {
	home, _ := os.UserHomeDir()
	roaming := os.Getenv("APPDATA")
	if roaming == "" && runtime.GOOS == "windows" && home != "" {
		roaming = filepath.Join(home, "AppData", "Roaming")
	}
	type entry struct{ path, name, source string }
	var candidates []entry
	add := func(path, name, source string) {
		if path != "" {
			candidates = append(candidates, entry{path, name, source})
		}
	}
	if current != "" {
		add(current, "Seçili oyun klasörü", "Kaydedilen")
	}
	if roaming != "" {
		add(filepath.Join(roaming, ".minecraft"), "TLauncher / .minecraft", "TLauncher / Minecraft")
	}
	if home != "" {
		add(filepath.Join(home, ".minecraft"), "Minecraft (.minecraft)", "Minecraft")
		add(filepath.Join(home, "TLauncher", ".minecraft"), "TLauncher (.minecraft)", "TLauncher")
		roots := []string{
			filepath.Join(home, "curseforge", "minecraft", "Instances"),
			filepath.Join(home, "Documents", "CurseForge", "Minecraft", "Instances"),
			filepath.Join(home, "CurseForge", "minecraft", "Instances"),
			filepath.Join(home, "Games", "CurseForge", "Minecraft", "Instances"),
		}
		for _, root := range roots {
			dirs, err := os.ReadDir(root)
			if err != nil {
				continue
			}
			for i, d := range dirs {
				if i >= 100 {
					break
				}
				if d.IsDir() {
					add(filepath.Join(root, d.Name()), "CurseForge · "+d.Name(), "CurseForge")
				}
			}
		}
	}
	seen := map[string]bool{}
	out := make([]ProfileCandidate, 0)
	for _, c := range candidates {
		path, details, err := validateGameFolder(c.path)
		if err != nil {
			continue
		}
		key := filepath.Clean(path)
		if runtime.GOOS == "windows" {
			key = strings.ToLower(key)
		}
		if seen[key] {
			continue
		}
		seen[key] = true
		out = append(out, ProfileCandidate{Name: c.name, Path: path, Source: c.source, Details: details})
	}
	// Keep the currently selected profile first, then put AGALAR instances near the top.
	sort.SliceStable(out, func(i, j int) bool {
		priority := func(v ProfileCandidate) int {
			if current != "" && strings.EqualFold(v.Path, filepath.Clean(current)) {
				return 0
			}
			if strings.Contains(strings.ToLower(v.Name), "agalar") {
				return 1
			}
			if strings.Contains(v.Source, "TLauncher") {
				return 2
			}
			return 3
		}
		return priority(out[i]) < priority(out[j])
	})
	return out
}
