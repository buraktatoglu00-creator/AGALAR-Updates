package main

import (
	"archive/zip"
	"bytes"
	"encoding/json"
	"io"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

func TestContentCategories(t *testing.T) {
	for _, tc := range []struct{ path, cat string }{
		{"mods/space.jar", "mods"}, {"resourcepacks/p.zip", "resourcepacks"},
		{"shaderpacks/a.zip", "shaderpacks"}, {"config/mod.toml", "config"},
		{"defaultconfigs/test.cfg", "defaultconfigs"}, {"scripts/a.zs", "scripts"},
		{"kubejs/server_scripts/test.js", "kubejs"}, {"datapacks/foo.zip", "datapacks"},
	} {
		if got := contentCategory(tc.path); got != tc.cat {
			t.Errorf("%s: %s", tc.path, got)
		}
	}
}

func TestConfigEditorMakesBackupAndValidatesJSON(t *testing.T) {
	root := t.TempDir()
	path := filepath.Join(root, "config", "example.json")
	if e := os.MkdirAll(filepath.Dir(path), 0700); e != nil {
		t.Fatal(e)
	}
	if e := os.WriteFile(path, []byte(`{"foo":true}`), 0600); e != nil {
		t.Fatal(e)
	}
	if e := saveSourceConfig(root, "config/example.json", `{"foo":`); e == nil {
		t.Fatal("invalid JSON accepted")
	}
	if e := saveSourceConfig(root, "config/example.json", `{"foo":false}`); e != nil {
		t.Fatal(e)
	}
	text, e := readSourceConfig(root, "config/example.json")
	if e != nil || text != `{"foo":false}` {
		t.Fatal(e, text)
	}
	backups, e := filepath.Glob(filepath.Join(root, ".agalar-trash", "*", "config", "example.json"))
	if e != nil || len(backups) != 1 {
		t.Fatal(backups, e)
	}
	b, e := os.ReadFile(backups[0])
	if e != nil || string(b) != `{"foo":true}` {
		t.Fatal(string(b), e)
	}
	if e := saveSourceConfig(root, "../saves/world", "data"); e == nil {
		t.Fatal("outside path accepted")
	}
}

func TestGraphicsPresetPreservesUnrelatedOptions(t *testing.T) {
	t.Setenv("XDG_CONFIG_HOME", t.TempDir())
	profile := t.TempDir()
	path := filepath.Join(profile, "options.txt")
	original := "key_key.attack:key.mouse.left\nrenderDistance:24\nparticles:0\nsoundCategory_master:0.4\n"
	if e := os.WriteFile(path, []byte(original), 0600); e != nil {
		t.Fatal(e)
	}
	if e := applyPlayerPreset(profile, "fps"); e != nil {
		t.Fatal(e)
	}
	b, e := os.ReadFile(path)
	if e != nil {
		t.Fatal(e)
	}
	for _, v := range []string{"key_key.attack:key.mouse.left", "renderDistance:8", "particles:2", "soundCategory_master:0.4"} {
		if !strings.Contains(string(b), v) {
			t.Errorf("missing %q in %s", v, string(b))
		}
	}
	backups, e := filepath.Glob(filepath.Join(dataDir(), "backups", "*", "options.txt"))
	if e != nil || len(backups) != 1 {
		t.Fatal(backups, e)
	}
	if e := applyPlayerPreset(profile, "malicious"); e == nil {
		t.Fatal("unknown preset allowed")
	}
}

func TestExportServerConfigsOnly(t *testing.T) {
	root := t.TempDir()
	for name := range map[string]string{"config/mod.toml": "a", "defaultconfigs/world.toml": "b", "mods/client.jar": "jar", "shaderpacks/a.zip": "shader"} {
		p := filepath.Join(root, filepath.FromSlash(name))
		os.MkdirAll(filepath.Dir(p), 0700)
		os.WriteFile(p, []byte(name), 0600)
	}
	archive := filepath.Join(t.TempDir(), "server.zip")
	n, e := exportServerConfigs(root, archive)
	if e != nil || n != 2 {
		t.Fatalf("%d %v", n, e)
	}
	zr, e := zip.OpenReader(archive)
	if e != nil {
		t.Fatal(e)
	}
	defer zr.Close()
	if len(zr.File) != 2 {
		t.Fatal(len(zr.File))
	}
	for _, f := range zr.File {
		if strings.HasPrefix(f.Name, "mods/") || strings.HasPrefix(f.Name, "shaderpacks/") {
			t.Fatal("client file exported", f.Name)
		}
	}
}

func TestUnifiedBuildAdminModeAndGuard(t *testing.T) {
	app := &App{token: "unit-test", cfg: Config{Admin: false, Source: t.TempDir()}, launched: time.Now(), lastRequest: time.Now()}
	req := httptest.NewRequest("POST", "http://127.0.0.1:1234/api/mode", strings.NewReader(`{"admin":true}`))
	req.Header.Set("X-AGALAR-Token", "unit-test")
	rec := httptest.NewRecorder()
	app.handle(rec, req)
	if rec.Code != 200 || !app.cfg.Admin {
		t.Fatalf("expected admin switch, got %d: %s", rec.Code, rec.Body.String())
	}
	req = httptest.NewRequest("POST", "http://127.0.0.1:1234/api/mode", strings.NewReader(`{"admin":false}`))
	req.Header.Set("X-AGALAR-Token", "unit-test")
	rec = httptest.NewRecorder()
	app.handle(rec, req)
	if rec.Code != 200 || app.cfg.Admin {
		t.Fatal("cannot return to player mode")
	}
	req = httptest.NewRequest("GET", "http://127.0.0.1:1234/api/config-read?path=config/a.toml", nil)
	req.Header.Set("X-AGALAR-Token", "unit-test")
	rec = httptest.NewRecorder()
	app.handle(rec, req)
	if rec.Code != 400 {
		t.Fatal("admin guard failed", rec.Code)
	}
}

func TestUIIncludesCategoriesAndConfigEditor(t *testing.T) {
	b, e := assets.ReadFile("ui.html")
	if e != nil {
		t.Fatal(e)
	}
	for _, name := range []string{"Paket İçerikleri", "Grafik Ayarları", "Tümü", "Kaynak Paketleri", "Shaderlar", "Data Packler", "config-save", "export-server"} {
		if !bytes.Contains(b, []byte(name)) {
			t.Fatal("missing", name)
		}
	}
}

var _ = json.Valid
var _ io.Reader
var _ http.Handler
