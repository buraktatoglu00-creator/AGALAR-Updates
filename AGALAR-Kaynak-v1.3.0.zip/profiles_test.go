package main

import (
	"bytes"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func fakeGameDir(t *testing.T) string {
	t.Helper()
	p := filepath.Join(t.TempDir(), ".minecraft")
	if e := os.MkdirAll(filepath.Join(p, "mods"), 0755); e != nil {
		t.Fatal(e)
	}
	if e := os.WriteFile(filepath.Join(p, "options.txt"), []byte("renderDistance:18\nsimulationDistance:11\n"), 0600); e != nil {
		t.Fatal(e)
	}
	return p
}
func TestProfilePathValidation(t *testing.T) {
	game := fakeGameDir(t)
	p, details, err := validateGameFolder(" \"" + game + "\" ")
	if err != nil || p != game || !strings.Contains(details, "Oyun ayarları") {
		t.Fatalf("game %q %q %v", p, details, err)
	}
	bad := t.TempDir()
	if _, _, err := validateGameFolder(bad); err == nil {
		t.Fatalf("accepted arbitrary directory %s", bad)
	}
	if _, _, err := validateGameFolder(filepath.Join(t.TempDir(), "missing")); err == nil {
		t.Fatal("missing folder accepted")
	}
	if _, err := canonicalFolder(filepath.Join(game, "options.txt")); err == nil {
		t.Fatal("file used as folder")
	}
}
func TestProfilesDiscovery(t *testing.T) {
	home := t.TempDir()
	t.Setenv("HOME", home)
	t.Setenv("APPDATA", filepath.Join(home, "AppData", "Roaming"))
	game := filepath.Join(home, "AppData", "Roaming", ".minecraft")
	if e := os.MkdirAll(game, 0755); e != nil {
		t.Fatal(e)
	}
	if e := os.WriteFile(filepath.Join(game, "options.txt"), []byte("renderDistance:18\n"), 0600); e != nil {
		t.Fatal(e)
	}
	cf := filepath.Join(home, "curseforge", "minecraft", "Instances", "AGALAR")
	if e := os.MkdirAll(cf, 0755); e != nil {
		t.Fatal(e)
	}
	if e := os.WriteFile(filepath.Join(cf, "minecraftinstance.json"), []byte("{}"), 0600); e != nil {
		t.Fatal(e)
	}
	out := detectMinecraftProfiles("")
	if len(out) != 2 {
		t.Fatalf("wanted two game directories: %+v", out)
	}
	if out[0].Path != cf {
		t.Fatalf("AGALAR should be prioritized: %+v", out)
	}
}
func TestProfileConfigRejectsWrongDirectory(t *testing.T) {
	token := "testtoken"
	cfg := Config{}
	app := &App{cfg: cfg, token: token}
	bad := t.TempDir()
	reqBody, _ := json.Marshal(map[string]string{"profile": bad})
	r := httptest.NewRequest(http.MethodPost, "/api/config", bytes.NewReader(reqBody))
	r.Header.Set("X-AGALAR-Token", token)
	w := httptest.NewRecorder()
	app.handle(w, r)
	if w.Code != 400 {
		t.Fatalf("expected 400, got %d: %s", w.Code, w.Body.String())
	}
	if app.cfg.Profile != "" {
		t.Fatalf("invalid path stored: %s", app.cfg.Profile)
	}
	good := fakeGameDir(t)
	reqBody, _ = json.Marshal(map[string]string{"path": good})
	r = httptest.NewRequest(http.MethodPost, "/api/validate-folder", bytes.NewReader(reqBody))
	r.Header.Set("X-AGALAR-Token", token)
	w = httptest.NewRecorder()
	app.handle(w, r)
	if w.Code != 200 {
		t.Fatalf("expected valid path: %d %s", w.Code, w.Body.String())
	}
}
