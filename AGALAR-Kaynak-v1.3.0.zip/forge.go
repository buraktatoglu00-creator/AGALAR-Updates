package main

import (
	"context"
	"crypto/sha1"
	"encoding/hex"
	"errors"
	"fmt"
	"io"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"time"
)

const forgeInstallerURL = "https://maven.minecraftforge.net/net/minecraftforge/forge/1.20.1-47.4.10/forge-1.20.1-47.4.10-installer.jar"

// Source: MinecraftForge official downloads page for recommended 47.4.10.
const forgeInstallerSHA1 = "66bfea9963bfa60d88bab6b2750e74a958392715"

func hasForgeVersion(versionsDir string) bool {
	entries, err := os.ReadDir(versionsDir)
	if err != nil {
		return false
	}
	for _, v := range entries {
		if !v.IsDir() {
			continue
		}
		name := strings.ToLower(v.Name())
		if strings.Contains(name, "1.20.1") && strings.Contains(name, "forge") && strings.Contains(name, "47.4.10") {
			return true
		}
	}
	return false
}

// The normal launcher stores versions under its game directory. CurseForge
// instances typically lack that folder and use a separate launcher-managed
// Forge; changing their shared loader location would be unsafe.
func (a *App) ensureForge(ctx context.Context, gameDir string) error {
	versions := filepath.Join(gameDir, "versions")
	if !existsDirectory(versions) {
		return nil
	} // Third-party launcher-managed profile.
	if hasForgeVersion(versions) {
		return nil
	}
	java, err := exec.LookPath("java")
	if err != nil {
		return errors.New("Forge 47.4.10 bulunamadı ve Java PATH üzerinde yok. Java 17 yükle veya başlatıcından Forge 47.4.10'u seç")
	}
	a.status.set(true, "Forge 47.4.10 hazırlanıyor...", "Resmî yükleyici indiriliyor", 1)
	tmpDir, err := os.MkdirTemp("", "agalar-forge-*")
	if err != nil {
		return err
	}
	defer os.RemoveAll(tmpDir)
	jar := filepath.Join(tmpDir, "forge-installer.jar")
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, forgeInstallerURL, nil)
	if err != nil {
		return err
	}
	client := &http.Client{Timeout: 5 * time.Minute}
	resp, err := client.Do(req)
	if err != nil {
		return fmt.Errorf("Forge indirilemedi: %w", err)
	}
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusOK {
		return fmt.Errorf("Forge yükleyicisi HTTP %d", resp.StatusCode)
	}
	f, err := os.Create(jar)
	if err != nil {
		return err
	}
	h := sha1.New()
	n, err := io.Copy(io.MultiWriter(f, h), io.LimitReader(resp.Body, 30<<20+1))
	if e := f.Close(); err == nil {
		err = e
	}
	if err != nil {
		return err
	}
	if n > 30<<20 {
		return errors.New("Forge yükleyicisi beklenenden büyük")
	}
	if hex.EncodeToString(h.Sum(nil)) != forgeInstallerSHA1 {
		return errors.New("Forge yükleyici SHA1 doğrulaması başarısız")
	}
	a.status.set(true, "Forge 47.4.10 kuruluyor...", "Java yükleyicisi çalışıyor", 2)
	// JVM may need to fetch official Mojang/Forge libraries. Command arguments are
	// fixed, and the installer jar has been verified against the official digest.
	output, err := exec.CommandContext(ctx, java, "-jar", jar, "--installClient", gameDir).CombinedOutput()
	if err != nil {
		detail := strings.TrimSpace(string(output))
		if len(detail) > 500 {
			detail = detail[len(detail)-500:]
		}
		return fmt.Errorf("Forge kurulumu başarısız: %w (%s)", err, detail)
	}
	if !hasForgeVersion(versions) {
		return errors.New("Forge yükleyicisi tamamlandı ancak 47.4.10 sürümü doğrulanamadı")
	}
	return nil
}
