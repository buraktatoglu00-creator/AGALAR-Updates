package main

import (
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func TestUploadLocalDuplicateAndBackup(t *testing.T) {
	root := t.TempDir()
	path, err := uploadLocal(root, "mods", "example.jar", strings.NewReader("first-build"), 1024)
	if err != nil || path != "mods/example.jar" {
		t.Fatalf("first upload: %q, %v", path, err)
	}
	path, err = uploadLocal(root, "mods", "example.jar", strings.NewReader("first-build"), 1024)
	if err != nil || path != "" {
		t.Fatalf("duplicate upload: %q, %v", path, err)
	}
	path, err = uploadLocal(root, "mods", "example.jar", strings.NewReader("second-build"), 1024)
	if err != nil || path != "mods/example.jar" {
		t.Fatalf("replacement: %q, %v", path, err)
	}
	items, err := os.ReadDir(filepath.Join(root, ".agalar-trash"))
	if err != nil || len(items) == 0 {
		t.Fatalf("no backup found: %v", err)
	}
	actual, err := os.ReadFile(filepath.Join(root, "mods", "example.jar"))
	if err != nil || string(actual) != "second-build" {
		t.Fatalf("unexpected replacement content: %v %q", err, actual)
	}
}
func TestUploadLocalRejectsUnsafeType(t *testing.T) {
	root := t.TempDir()
	for _, tc := range []struct{ cat, name string }{
		{"mods", "inject.exe"}, {"mods", "script.bat"}, {"mods", "wrong.zip"}, {"shaderpacks", "wrong.jar"}, {"datapacks", "shell.exe"},
	} {
		_, err := uploadLocal(root, tc.cat, tc.name, strings.NewReader("payload"), 100)
		if err == nil {
			t.Errorf("accepted unsafe category %s: %s", tc.cat, tc.name)
		}
	}
}
func TestUploadLocalRejectsSymlinkFolders(t *testing.T) {
	root := t.TempDir()
	outside := t.TempDir()
	if err := os.Symlink(outside, filepath.Join(root, "mods")); err != nil {
		t.Skipf("no symlink support: %v", err)
	}
	if _, err := uploadLocal(root, "mods", "danger.jar", strings.NewReader("data"), 100); err == nil {
		t.Fatal("symlink target accepted")
	}
	if _, err := os.Stat(filepath.Join(outside, "danger.jar")); !os.IsNotExist(err) {
		t.Fatal("file escaped source")
	}
}
