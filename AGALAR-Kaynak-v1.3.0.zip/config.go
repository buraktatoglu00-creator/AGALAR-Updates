package main

import (
	"crypto/rand"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"io"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"time"
)

const appVersion = "1.3.0"
const githubOwner = "buraktatoglu00-creator"
const githubRepo = "AGALAR-Updates"
const minecraftVersion = "1.20.1"
const forgeVersion = "47.4.10"

var categories = map[string]bool{"mods": true, "resourcepacks": true, "shaderpacks": true, "config": true, "defaultconfigs": true, "kubejs": true, "scripts": true, "datapacks": true}

type Config struct {
	Profile      string `json:"profile"`
	Source       string `json:"source"`
	LocalVersion string `json:"local_version"`
	Admin        bool   `json:"admin"`
}
type InstalledFile struct {
	Path   string `json:"path"`
	SHA256 string `json:"sha256"`
}
type Installed struct {
	Version string          `json:"version"`
	Files   []InstalledFile `json:"files"`
}
type PackFile struct {
	Path    string `json:"path"`
	Size    int64  `json:"size"`
	SHA256  string `json:"sha256"`
	URL     string `json:"url"`
	AssetID int64  `json:"-"`
}
type PackManifest struct {
	Version   string     `json:"version"`
	Minecraft string     `json:"minecraft"`
	Forge     string     `json:"forge"`
	Notes     string     `json:"notes"`
	Files     []PackFile `json:"files"`
}
type AppManifest struct {
	Version string `json:"version"`
	File    string `json:"file"`
	Size    int64  `json:"size"`
	SHA256  string `json:"sha256"`
}

type Status struct {
	sync.Mutex
	Busy    bool      `json:"busy"`
	Message string    `json:"message"`
	Percent int       `json:"percent"`
	Detail  string    `json:"detail"`
	Started time.Time `json:"-"`
}

func (s *Status) set(b bool, m, d string, p int) {
	s.Lock()
	if b && !s.Busy {
		s.Started = time.Now()
	}
	s.Busy = b
	s.Message = m
	s.Detail = d
	s.Percent = p
	s.Unlock()
}
func (s *Status) snapshot() StatusSnapshot {
	s.Lock()
	defer s.Unlock()
	eta := -1
	if s.Busy && s.Percent >= 3 && s.Percent < 100 && !s.Started.IsZero() {
		elapsed := time.Since(s.Started).Seconds()
		eta = int(elapsed * float64(100-s.Percent) / float64(s.Percent))
		if eta > 24*60*60 {
			eta = -1
		}
	}
	return StatusSnapshot{Busy: s.Busy, Message: s.Message, Detail: s.Detail, Percent: s.Percent, ETASeconds: eta}
}

type StatusSnapshot struct {
	Busy       bool   `json:"busy"`
	Message    string `json:"message"`
	Detail     string `json:"detail"`
	Percent    int    `json:"percent"`
	ETASeconds int    `json:"eta_seconds"`
}

func randomToken() string {
	b := make([]byte, 32)
	if _, e := rand.Read(b); e != nil {
		panic(e)
	}
	return hex.EncodeToString(b)
}
func dataDir() string {
	p, e := os.UserConfigDir()
	if e != nil {
		p = os.TempDir()
	}
	return filepath.Join(p, "AGALAR-Modpack-Manager")
}
func configPath() string { return filepath.Join(dataDir(), "config.json") }
func readConfig() Config {
	var c Config
	b, e := os.ReadFile(configPath())
	if e == nil {
		_ = json.Unmarshal(b, &c)
	}
	return c
}
func writeConfig(c Config) error { return atomicJSON(configPath(), c) }
func installedPath(profile string) string {
	key := sha256.Sum256([]byte(strings.ToLower(filepath.Clean(profile))))
	return filepath.Join(dataDir(), "profiles", hex.EncodeToString(key[:8])+".json")
}
func readInstalled(profile string) Installed {
	var s Installed
	b, e := os.ReadFile(installedPath(profile))
	if e == nil {
		_ = json.Unmarshal(b, &s)
	}
	return s
}
func atomicJSON(path string, v any) error {
	b, e := json.MarshalIndent(v, "", "  ")
	if e != nil {
		return e
	}
	return atomicBytes(path, append(b, '\n'))
}
func atomicBytes(path string, b []byte) error {
	if e := os.MkdirAll(filepath.Dir(path), 0700); e != nil {
		return e
	}
	f, e := os.CreateTemp(filepath.Dir(path), ".agalar-write-*")
	if e != nil {
		return e
	}
	tmp := f.Name()
	defer os.Remove(tmp)
	if _, e = f.Write(b); e != nil {
		f.Close()
		return e
	}
	if e = f.Sync(); e != nil {
		f.Close()
		return e
	}
	if e = f.Close(); e != nil {
		return e
	}
	if e = os.Rename(tmp, path); e != nil { // Windows does not replace existing destination by os.Rename on some versions.
		backup := path + ".old"
		_ = os.Remove(backup)
		if e2 := os.Rename(path, backup); e2 != nil && !errors.Is(e2, os.ErrNotExist) {
			return e
		}
		if e2 := os.Rename(tmp, path); e2 != nil {
			_ = os.Rename(backup, path)
			return e2
		}
		_ = os.Remove(backup)
	}
	return nil
}
func fileCopy(dst, src string) error {
	in, e := os.Open(src)
	if e != nil {
		return e
	}
	defer in.Close()
	if e = os.MkdirAll(filepath.Dir(dst), 0700); e != nil {
		return e
	}
	out, e := os.OpenFile(dst, os.O_WRONLY|os.O_CREATE|os.O_TRUNC, 0600)
	if e != nil {
		return e
	}
	_, e = io.Copy(out, in)
	if mode, statErr := in.Stat(); statErr == nil {
		_ = out.Chmod(mode.Mode().Perm())
	}
	if closeErr := out.Close(); e == nil {
		e = closeErr
	}
	return e
}
func safeRelative(p string) (string, error) {
	p = strings.ReplaceAll(p, "\\", "/")
	if p == "" || strings.HasPrefix(p, "/") || strings.Contains(p, ":") || strings.ContainsRune(p, 0) {
		return "", errors.New("Geçersiz dosya yolu")
	}
	parts := strings.Split(p, "/")
	for _, s := range parts {
		if s == "" || s == "." || s == ".." || strings.HasSuffix(s, ".") || strings.HasSuffix(s, " ") {
			return "", errors.New("Güvensiz dosya yolu")
		}
	}
	if !categories[parts[0]] || len(parts) < 2 {
		return "", errors.New("Desteklenmeyen klasör")
	}
	// A pack must never touch saves, the launcher, executables or the Windows profile.
	return filepath.FromSlash(p), nil
}
func localFilePath(root, rel string) (string, error) {
	r, e := safeRelative(rel)
	if e != nil {
		return "", e
	}
	return filepath.Join(root, r), nil
}
func versionCmp(a, b string) int {
	var aa, bb [3]int
	_, _ = fmtSscanfVersion(a, &aa)
	_, _ = fmtSscanfVersion(b, &bb)
	for i := 0; i < 3; i++ {
		if aa[i] > bb[i] {
			return 1
		}
		if aa[i] < bb[i] {
			return -1
		}
	}
	return 0
}
func fmtSscanfVersion(s string, v *[3]int) (int, error) {
	n := 0
	for i, part := range strings.SplitN(strings.TrimPrefix(s, "v"), ".", 3) {
		if i > 2 {
			break
		}
		num := 0
		if part == "" {
			return n, errors.New("Geçersiz sürüm")
		}
		for _, ch := range part {
			if ch < '0' || ch > '9' {
				return n, errors.New("Geçersiz sürüm")
			}
			num = num*10 + int(ch-'0')
		}
		v[i] = num
		n++
	}
	return n, nil
}
func backupDir() string {
	return filepath.Join(dataDir(), "backups", time.Now().UTC().Format("20060102-150405.000000000"))
}
