package main

import (
	"bufio"
	"bytes"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"time"
)

var playerPresets = map[string]map[string]string{
	"fps":      {"renderDistance": "8", "simulationDistance": "5", "graphicsMode": "0", "particles": "2", "entityDistanceScaling": "0.75", "mipmapLevels": "2"},
	"balanced": {"renderDistance": "12", "simulationDistance": "8", "graphicsMode": "1", "particles": "1", "entityDistanceScaling": "1.0", "mipmapLevels": "4"},
	"quality":  {"renderDistance": "16", "simulationDistance": "10", "graphicsMode": "1", "particles": "0", "entityDistanceScaling": "1.0", "mipmapLevels": "4"},
}

// These are vanilla Minecraft client options only; no server-enforced gameplay settings are changed.
func applyPlayerPreset(profile, preset string) error {
	changes, ok := playerPresets[preset]
	if !ok {
		return errors.New("Geçersiz grafik profili")
	}
	if profile == "" {
		return errors.New("Önce oyun klasörünü seç")
	}
	validated, _, e := validateGameFolder(profile)
	if e != nil {
		return e
	}
	path := filepath.Join(validated, "options.txt")
	contents, e := os.ReadFile(path)
	if e != nil && !os.IsNotExist(e) {
		return e
	}
	if len(contents) > 2<<20 {
		return errors.New("options.txt beklenenden büyük")
	}
	if e == nil {
		bak := filepath.Join(dataDir(), "backups", time.Now().UTC().Format("20060102-150405.000000000"), "options.txt")
		if err := fileCopy(bak, path); err != nil {
			return fmt.Errorf("Oyuncu ayarları yedeklenemedi: %w", err)
		}
	}
	var buf bytes.Buffer
	scanner := bufio.NewScanner(bytes.NewReader(contents))
	scanner.Buffer(make([]byte, 4096), 2<<20)
	visited := map[string]bool{}
	for scanner.Scan() {
		line := scanner.Text()
		parts := strings.SplitN(line, ":", 2)
		if len(parts) == 2 {
			if val, ok := changes[parts[0]]; ok {
				line = parts[0] + ":" + val
				visited[parts[0]] = true
			}
		}
		buf.WriteString(line + "\n")
	}
	if e = scanner.Err(); e != nil {
		return e
	}
	// Missing keys are left to Minecraft defaults; do not add unknown keys to a user's options file.
	_ = visited
	if len(contents) == 0 {
		return errors.New("options.txt henüz yok. Minecraft'ı bir kez açıp kapattıktan sonra tekrar dene")
	}
	return atomicBytes(path, buf.Bytes())
}
