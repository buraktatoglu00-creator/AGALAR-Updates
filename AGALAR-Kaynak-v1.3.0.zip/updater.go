package main

import (
	"context"
	"errors"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"strings"
	"time"
)

func (a *App) updateSelf() error {
	ctx, cancel := context.WithTimeout(context.Background(), 90*time.Minute)
	defer cancel()
	release, ok, e := newestRelease(ctx, "app-v")
	if e != nil {
		return e
	}
	if !ok {
		return errors.New("Uygulama için henüz GitHub yayını yok")
	}
	manifest, asset, e := fetchAppManifest(ctx, release)
	if e != nil {
		return e
	}
	if versionCmp(manifest.Version, appVersion) <= 0 {
		return errors.New("Zaten en yeni uygulama sürümündesin")
	}
	if asset.Size != manifest.Size {
		return errors.New("Yeni EXE boyutu sürüm bilgisiyle uyuşmuyor")
	}
	self, e := os.Executable()
	if e != nil {
		return e
	}
	self, e = filepath.Abs(self)
	if e != nil {
		return e
	}
	stage := filepath.Join(dataDir(), "staging", fmt.Sprintf("AGALAR-%s.exe", manifest.Version))
	a.status.set(true, "Uygulama indiriliyor...", "SHA-256 doğrulaması yapılacak", 5)
	e = downloadVerified(ctx, asset.URL, stage, manifest.SHA256, manifest.Size, func(n int64) {
		pct := 5 + int(float64(n)/float64(manifest.Size)*85)
		a.status.set(true, "Uygulama indiriliyor...", fmt.Sprintf("%.1f / %.1f MB", float64(n)/1048576, float64(manifest.Size)/1048576), pct)
	})
	if e != nil {
		return e
	}
	helper := filepath.Join(dataDir(), "staging", fmt.Sprintf("AGALAR-updater-%d.exe", time.Now().UnixNano()))
	if e = fileCopy(helper, self); e != nil {
		return e
	}
	a.status.set(true, "Uygulama yeniden başlatılıyor...", "Yeni sürüm doğrulandı", 95)
	cmd := exec.Command(helper, "--replace", self, stage, manifest.SHA256)
	if e = cmd.Start(); e != nil {
		return fmt.Errorf("Güncelleyici başlatılamadı: %w", e)
	}
	// The helper is a temporary copy of the same EXE. Users only install/manage AGALAR.exe.
	go func() { time.Sleep(600 * time.Millisecond); os.Exit(0) }()
	return nil
}
func replaceSelf(args []string) error {
	if len(args) != 3 {
		return errors.New("Güncelleme parametreleri eksik")
	}
	target, stage, expected := args[0], args[1], args[2]
	if !strings.EqualFold(filepath.Base(target), "AGALAR.exe") {
		return errors.New("Güvenli olmayan uygulama hedefi")
	}
	if filepath.Clean(stage) == filepath.Clean(target) {
		return errors.New("Aynı dosya güncellenemez")
	}
	digest, _, e := shaFile(stage)
	if e != nil {
		return e
	}
	if !strings.EqualFold(digest, expected) {
		return errors.New("İndirilen EXE doğrulanamadı")
	}
	// The running parent executable cannot be overwritten on Windows; retry after it exits.
	backup := target + ".previous"
	newFile := target + ".new"
	if e = fileCopy(newFile, stage); e != nil {
		return e
	}
	swapped := false
	for i := 0; i < 120; i++ {
		if runtime.GOOS == "windows" {
			time.Sleep(500 * time.Millisecond)
		}
		_ = os.Remove(backup)
		e = os.Rename(target, backup)
		if e != nil {
			time.Sleep(500 * time.Millisecond)
			continue
		}
		if e = os.Rename(newFile, target); e != nil {
			_ = os.Rename(backup, target)
			time.Sleep(500 * time.Millisecond)
			continue
		}
		swapped = true
		break
	}
	if !swapped {
		return errors.New("Eski EXE değiştirilemedi; yeni dosya .new olarak duruyor")
	}
	cmd := exec.Command(target, "--updated")
	if e = cmd.Start(); e != nil {
		_ = os.Remove(target)
		_ = os.Rename(backup, target)
		return fmt.Errorf("Yeni sürüm açılamadı: %w", e)
	}
	_ = os.Remove(stage)
	// Keep .previous as an emergency rollback copy; the user-facing application remains just AGALAR.exe.
	return nil
}
