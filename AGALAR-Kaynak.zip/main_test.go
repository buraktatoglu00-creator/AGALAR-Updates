package main

import (
	"bytes"
	"context"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"io"
	"mime/multipart"
	"net/http"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func TestSafeRelative(t *testing.T) {
	good := []string{"mods/a.jar", "resourcepacks/nested/a.zip", "config/sub/a.toml", "datapacks/demo/data/a.json"}
	bad := []string{"", "/etc/passwd", "mods/../saves/level.dat", "saves/a", "mods", "mods//abc", "mods/.hidden/../x", "C:/Windows/a", "mods/abc\\..\\a", "mods/end.", "mods/foo ", "mods/"}
	for _, p := range good {
		if _, e := safeRelative(p); e != nil {
			t.Errorf("good %q rejected: %v", p, e)
		}
	}
	for _, p := range bad {
		if _, e := safeRelative(p); e == nil {
			t.Errorf("bad %q accepted", p)
		}
	}
}
func TestVersionCmp(t *testing.T) {
	for _, p := range []struct {
		a, b string
		want int
	}{{"1.0.0", "0.6.2", 1}, {"1.0.10", "1.0.9", 1}, {"1.0.0", "1.0.0", 0}, {"1.0.0", "1.1.0", -1}} {
		if got := versionCmp(p.a, p.b); got != p.want {
			t.Fatalf("%v got %d", p, got)
		}
	}
}
func TestUploadAndTrash(t *testing.T) {
	root := t.TempDir()
	b := []byte("jar-data")
	name, e := uploadLocal(root, "mods", "animals/example.jar", io.NopCloser(bytes.NewReader(b)), 200)
	if e != nil {
		t.Fatal(e)
	}
	if name != "mods/animals/example.jar" {
		t.Fatal(name)
	}
	got, e := os.ReadFile(filepath.Join(root, "mods", "animals", "example.jar"))
	if e != nil || !bytes.Equal(b, got) {
		t.Fatal(e)
	}
	if _, e = uploadLocal(root, "mods", "animals/example.jar", io.NopCloser(bytes.NewReader([]byte("different"))), 200); e != nil {
		t.Fatal(e)
	}
	if e = removeLocal(root, "mods/animals/example.jar"); e != nil {
		t.Fatal(e)
	}
	if _, e = os.Stat(filepath.Join(root, "mods", "animals", "example.jar")); !os.IsNotExist(e) {
		t.Fatalf("expected removed: %v", e)
	}
	matches, e := filepath.Glob(filepath.Join(root, ".agalar-trash", "*", "mods", "animals", "example.jar"))
	if e != nil || len(matches) != 1 {
		t.Fatalf("trash %v: %v", matches, e)
	}
}
func TestDownloadChecksHash(t *testing.T) {
	payload := []byte("test payload")
	sha := sha256.Sum256(payload)
	orig := transferClient
	defer func() { transferClient = orig }()
	transferClient = &http.Client{Transport: roundTrip(func(req *http.Request) (*http.Response, error) {
		return &http.Response{StatusCode: 200, Body: io.NopCloser(bytes.NewReader(payload)), Header: make(http.Header), Request: req}, nil
	})}
	path := filepath.Join(t.TempDir(), "jar")
	url := "https://github.com/" + githubOwner + "/" + githubRepo + "/releases/download/pack-v1.0.0/obj-test"
	if e := downloadVerified(context.Background(), url, path, hex.EncodeToString(sha[:]), int64(len(payload)), nil); e != nil {
		t.Fatal(e)
	}
	if _, e := os.Stat(path); e != nil {
		t.Fatal(e)
	}
	if e := downloadVerified(context.Background(), url, path+"bad", strings.Repeat("a", 64), int64(len(payload)), nil); e == nil {
		t.Fatal("bad hash accepted")
	}
	if _, e := os.Stat(path + "bad"); !os.IsNotExist(e) {
		t.Fatalf("bad file remained: %v", e)
	}
}

type roundTrip func(*http.Request) (*http.Response, error)

func (f roundTrip) RoundTrip(r *http.Request) (*http.Response, error) { return f(r) }
func TestManifestSafety(t *testing.T) {
	ctx := context.Background()
	m := PackManifest{Version: "1.0.0", Minecraft: minecraftVersion, Forge: forgeVersion, Files: []PackFile{{Path: "mods/../saves/level.dat", Size: 1, SHA256: strings.Repeat("b", 64), URL: "https://github.com/" + githubOwner + "/" + githubRepo + "/releases/download/pack-v1.0.0/bad"}}}
	b, _ := json.Marshal(m)
	old := transferClient
	defer func() { transferClient = old }()
	transferClient = &http.Client{Transport: roundTrip(func(req *http.Request) (*http.Response, error) {
		return &http.Response{StatusCode: 200, Body: io.NopCloser(bytes.NewReader(b)), Header: make(http.Header), Request: req}, nil
	})}
	rel := GHRelease{Tag: "pack-v1.0.0", Assets: []ReleaseAsset{{Name: "pack-manifest.json", URL: "https://github.com/" + githubOwner + "/" + githubRepo + "/releases/download/pack-v1.0.0/pack-manifest.json"}}}
	if _, e := fetchPackManifest(ctx, rel); e == nil {
		t.Fatal("malicious path accepted")
	}
}
func TestMultipartUpload(t *testing.T) {
	root := t.TempDir()
	var buf bytes.Buffer
	w := multipart.NewWriter(&buf)
	_ = w.WriteField("category", "mods")
	_ = w.WriteField("relative", "nested/a.jar")
	f, e := w.CreateFormFile("files", "a.jar")
	if e != nil {
		t.Fatal(e)
	}
	f.Write([]byte("a"))
	w.Close()
	req, _ := http.NewRequest("POST", "http://127.0.0.1/api/upload", &buf)
	req.Header.Set("Content-Type", w.FormDataContentType())
	if e = req.ParseMultipartForm(1 << 20); e != nil {
		t.Fatal(e)
	}
	for _, fh := range req.MultipartForm.File["files"] {
		file, e := fh.Open()
		if e != nil {
			t.Fatal(e)
		}
		_, e = uploadLocal(root, req.FormValue("category"), req.FormValue("relative"), file, 100)
		file.Close()
		if e != nil {
			t.Fatal(e)
		}
	}
	if _, e = os.Stat(filepath.Join(root, "mods", "nested", "a.jar")); e != nil {
		t.Fatal(e)
	}
}

func TestInstallAndUpdateKeepsUserFiles(t *testing.T) {
	configHome := t.TempDir()
	t.Setenv("XDG_CONFIG_HOME", configHome)
	profile := filepath.Join(t.TempDir(), "profile")
	if e := os.MkdirAll(filepath.Join(profile, "mods"), 0755); e != nil {
		t.Fatal(e)
	}
	custom := filepath.Join(profile, "mods", "user-own.jar")
	if e := os.WriteFile(custom, []byte("never remove"), 0600); e != nil {
		t.Fatal(e)
	}
	world := filepath.Join(profile, "saves", "My World")
	if e := os.MkdirAll(world, 0755); e != nil {
		t.Fatal(e)
	}
	if e := os.WriteFile(filepath.Join(world, "level.dat"), []byte("saved-world"), 0600); e != nil {
		t.Fatal(e)
	}
	jar := []byte("AGALAR-JAR-v1")
	sum := sha256.Sum256(jar)
	digest := hex.EncodeToString(sum[:])
	objURL := "https://github.com/" + githubOwner + "/" + githubRepo + "/releases/download/pack-v1.0.0/obj-" + digest
	manifest := PackManifest{Version: "1.0.0", Minecraft: minecraftVersion, Forge: forgeVersion, Files: []PackFile{{Path: "mods/agalar.jar", Size: int64(len(jar)), SHA256: digest, URL: objURL}}}
	data, _ := json.Marshal(manifest)
	releases := []GHRelease{{Tag: "pack-v1.0.0", Assets: []ReleaseAsset{{Name: "pack-manifest.json", URL: "https://github.com/" + githubOwner + "/" + githubRepo + "/releases/download/pack-v1.0.0/pack-manifest.json"}}}}
	listing, _ := json.Marshal(releases)
	originalAPI, originalTransfer := apiClient, transferClient
	defer func() { apiClient = originalAPI; transferClient = originalTransfer }()
	apiClient = &http.Client{Transport: roundTrip(func(req *http.Request) (*http.Response, error) {
		return &http.Response{StatusCode: 200, Body: io.NopCloser(bytes.NewReader(listing)), Header: make(http.Header), Request: req}, nil
	})}
	transferClient = &http.Client{Transport: roundTrip(func(req *http.Request) (*http.Response, error) {
		body := data
		if strings.Contains(req.URL.Path, "/obj-") {
			body = jar
		}
		return &http.Response{StatusCode: 200, Body: io.NopCloser(bytes.NewReader(body)), Header: make(http.Header), Request: req}, nil
	})}
	app := &App{cfg: Config{Profile: profile}}
	if e := app.installPack(); e != nil {
		t.Fatal(e)
	}
	if b, e := os.ReadFile(filepath.Join(profile, "mods", "agalar.jar")); e != nil || !bytes.Equal(b, jar) {
		t.Fatalf("jar %v", e)
	}
	if b, e := os.ReadFile(custom); e != nil || string(b) != "never remove" {
		t.Fatal("user file lost")
	}
	if b, e := os.ReadFile(filepath.Join(world, "level.dat")); e != nil || string(b) != "saved-world" {
		t.Fatal("world modified")
	}
	if installed := readInstalled(profile); installed.Version != "1.0.0" || len(installed.Files) != 1 {
		t.Fatalf("installed index wrong: %#v", installed)
	}
	if e := app.installPack(); e != nil {
		t.Fatal("second idempotent install:", e)
	}
	// A new release removes the old managed mod, but leaves the user's own jar and world untouched.
	newer := PackManifest{Version: "1.0.1", Minecraft: minecraftVersion, Forge: forgeVersion, Files: []PackFile{}}
	data, _ = json.Marshal(newer)
	releases = []GHRelease{{Tag: "pack-v1.0.1", Assets: []ReleaseAsset{{Name: "pack-manifest.json", URL: "https://github.com/" + githubOwner + "/" + githubRepo + "/releases/download/pack-v1.0.1/pack-manifest.json"}}}}
	listing, _ = json.Marshal(releases)
	if e := app.installPack(); e != nil {
		t.Fatal(e)
	}
	if _, e := os.Stat(filepath.Join(profile, "mods", "agalar.jar")); !os.IsNotExist(e) {
		t.Fatalf("managed removed file remained: %v", e)
	}
	if _, e := os.Stat(custom); e != nil {
		t.Fatal("user mod deleted")
	}
	if _, e := os.Stat(filepath.Join(world, "level.dat")); e != nil {
		t.Fatal("world deleted")
	}
	backup, e := filepath.Glob(filepath.Join(dataDir(), "backups", "*", "mods", "agalar.jar"))
	if e != nil || len(backup) == 0 {
		t.Fatalf("backup missing %v %v", backup, e)
	}
}

func TestAppUpdaterRollsBackWhenCannotLaunch(t *testing.T) {
	root := t.TempDir()
	target := filepath.Join(root, "AGALAR.exe")
	stage := filepath.Join(root, "downloaded.exe")
	if e := os.WriteFile(target, []byte("old"), 0755); e != nil {
		t.Fatal(e)
	}
	if e := os.WriteFile(stage, []byte("new-not-executable"), 0644); e != nil {
		t.Fatal(e)
	}
	sha, _, e := shaFile(stage)
	if e != nil {
		t.Fatal(e)
	}
	e = replaceSelf([]string{target, stage, sha})
	if e == nil {
		t.Fatal("should fail to launch malformed binary")
	}
	b, e := os.ReadFile(target)
	if e != nil || string(b) != "old" {
		t.Fatal("rollback failed")
	}
}
