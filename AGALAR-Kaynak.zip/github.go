package main

import (
	"bytes"
	"context"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"time"
)

type ReleaseAsset struct {
	Name string `json:"name"`
	Size int64  `json:"size"`
	URL  string `json:"browser_download_url"`
}
type GHRelease struct {
	ID         int64          `json:"id"`
	Tag        string         `json:"tag_name"`
	Draft      bool           `json:"draft"`
	Prerelease bool           `json:"prerelease"`
	Assets     []ReleaseAsset `json:"assets"`
	UploadURL  string         `json:"upload_url"`
}

var apiClient = &http.Client{Timeout: 35 * time.Second}
var transferClient = &http.Client{Timeout: 0, Transport: &http.Transport{Proxy: http.ProxyFromEnvironment, MaxIdleConns: 20, IdleConnTimeout: 40 * time.Second, TLSHandshakeTimeout: 15 * time.Second, ResponseHeaderTimeout: 35 * time.Second}}

func apiURL(s string) string {
	return "https://api.github.com/repos/" + githubOwner + "/" + githubRepo + s
}
func githubJSON(ctx context.Context, method, path, token string, reqObj any, out any) error {
	var body io.Reader
	if reqObj != nil {
		b, e := json.Marshal(reqObj)
		if e != nil {
			return e
		}
		body = bytes.NewReader(b)
	}
	req, e := http.NewRequestWithContext(ctx, method, apiURL(path), body)
	if e != nil {
		return e
	}
	req.Header.Set("Accept", "application/vnd.github+json")
	req.Header.Set("X-GitHub-Api-Version", "2022-11-28")
	req.Header.Set("User-Agent", "AGALAR-Manager/"+appVersion)
	if token != "" {
		req.Header.Set("Authorization", "Bearer "+token)
	}
	if reqObj != nil {
		req.Header.Set("Content-Type", "application/json")
	}
	resp, e := apiClient.Do(req)
	if e != nil {
		return e
	}
	defer resp.Body.Close()
	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		b, _ := io.ReadAll(io.LimitReader(resp.Body, 1024))
		return fmt.Errorf("GitHub yanıtı %d: %s", resp.StatusCode, strings.TrimSpace(string(b)))
	}
	if out == nil {
		return nil
	}
	return json.NewDecoder(io.LimitReader(resp.Body, 8<<20)).Decode(out)
}
func listReleases(ctx context.Context) ([]GHRelease, error) {
	var out []GHRelease
	e := githubJSON(ctx, "GET", "/releases?per_page=100", "", nil, &out)
	return out, e
}
func newestRelease(ctx context.Context, prefix string) (GHRelease, bool, error) {
	list, e := listReleases(ctx)
	if e != nil {
		return GHRelease{}, false, e
	}
	var best GHRelease
	found := false
	for _, r := range list {
		if r.Draft || r.Prerelease || !strings.HasPrefix(r.Tag, prefix) {
			continue
		}
		v := strings.TrimPrefix(r.Tag, prefix)
		if _, err := fmtSscanfVersion(v, &[3]int{}); err != nil {
			continue
		}
		if !found || versionCmp(v, strings.TrimPrefix(best.Tag, prefix)) > 0 {
			best = r
			found = true
		}
	}
	return best, found, nil
}
func findAsset(r GHRelease, name string) (ReleaseAsset, error) {
	for _, a := range r.Assets {
		if a.Name == name {
			return a, nil
		}
	}
	return ReleaseAsset{}, fmt.Errorf("%s, GitHub sürümünde bulunamadı", name)
}
func safeAssetURL(link string) error {
	u, e := url.Parse(link)
	if e != nil {
		return e
	}
	if u.Scheme != "https" || !strings.EqualFold(u.Hostname(), "github.com") || u.Port() != "" {
		return errors.New("Yalnızca GitHub HTTPS dosyaları kabul edilir")
	}
	prefix := "/" + githubOwner + "/" + githubRepo + "/releases/download/"
	if !strings.HasPrefix(u.EscapedPath(), prefix) {
		return errors.New("İndirme adresi izinli AGALAR deposundan değil")
	}
	return nil
}
func downloadBytes(ctx context.Context, link string, max int64) ([]byte, error) {
	if e := safeAssetURL(link); e != nil {
		return nil, e
	}
	req, e := http.NewRequestWithContext(ctx, "GET", link, nil)
	if e != nil {
		return nil, e
	}
	req.Header.Set("User-Agent", "AGALAR-Manager/"+appVersion)
	res, e := transferClient.Do(req)
	if e != nil {
		return nil, e
	}
	defer res.Body.Close()
	if res.StatusCode != 200 {
		return nil, fmt.Errorf("İndirme yanıtı: HTTP %d", res.StatusCode)
	}
	b, e := io.ReadAll(io.LimitReader(res.Body, max+1))
	if e != nil {
		return nil, e
	}
	if int64(len(b)) > max {
		return nil, errors.New("Dosya izin verilen boyutu aştı")
	}
	return b, nil
}
func fetchPackManifest(ctx context.Context, r GHRelease) (PackManifest, error) {
	var p PackManifest
	a, e := findAsset(r, "pack-manifest.json")
	if e != nil {
		return p, e
	}
	b, e := downloadBytes(ctx, a.URL, 16<<20)
	if e != nil {
		return p, e
	}
	if e = json.Unmarshal(b, &p); e != nil {
		return p, e
	}
	if p.Minecraft != minecraftVersion || p.Forge != forgeVersion {
		return p, errors.New("Minecraft/Forge sürümü uyuşmuyor")
	}
	if p.Version != strings.TrimPrefix(r.Tag, "pack-v") {
		return p, errors.New("Paket sürüm bilgisi uyuşmuyor")
	}
	if len(p.Files) > 20000 {
		return p, errors.New("Dosya sayısı çok yüksek")
	}
	seen := make(map[string]bool)
	for _, f := range p.Files {
		if _, e = safeRelative(f.Path); e != nil {
			return p, e
		}
		if seen[strings.ToLower(f.Path)] {
			return p, errors.New("Yinelenen dosya yolu")
		}
		seen[strings.ToLower(f.Path)] = true
		if f.Size < 0 || f.Size > 2<<30 || len(f.SHA256) != 64 {
			return p, errors.New("Geçersiz dosya bilgisi")
		}
		if _, e = hex.DecodeString(f.SHA256); e != nil {
			return p, e
		}
		if e = safeAssetURL(f.URL); e != nil {
			return p, e
		}
	}
	return p, nil
}
func fetchAppManifest(ctx context.Context, r GHRelease) (AppManifest, ReleaseAsset, error) {
	var p AppManifest
	a, e := findAsset(r, "app-manifest.json")
	if e != nil {
		return p, ReleaseAsset{}, e
	}
	b, e := downloadBytes(ctx, a.URL, 1<<20)
	if e != nil {
		return p, ReleaseAsset{}, e
	}
	if e = json.Unmarshal(b, &p); e != nil {
		return p, ReleaseAsset{}, e
	}
	if p.Version != strings.TrimPrefix(r.Tag, "app-v") || p.File != "AGALAR.exe" || len(p.SHA256) != 64 || p.Size < 1024 || p.Size > 200<<20 {
		return p, ReleaseAsset{}, errors.New("Geçersiz uygulama sürüm bildirimi")
	}
	if _, e = hex.DecodeString(p.SHA256); e != nil {
		return p, ReleaseAsset{}, e
	}
	a, e = findAsset(r, "AGALAR.exe")
	return p, a, e
}
func downloadVerified(ctx context.Context, link, target, expected string, size int64, progress func(int64)) error {
	if e := safeAssetURL(link); e != nil {
		return e
	}
	if size < 0 || size > 2<<30 {
		return errors.New("İndirme boyutu geçersiz")
	}
	req, e := http.NewRequestWithContext(ctx, "GET", link, nil)
	if e != nil {
		return e
	}
	req.Header.Set("User-Agent", "AGALAR-Manager/"+appVersion)
	res, e := transferClient.Do(req)
	if e != nil {
		return e
	}
	defer res.Body.Close()
	if res.StatusCode != 200 {
		return fmt.Errorf("İndirme başarısız: HTTP %d", res.StatusCode)
	}
	if e = os.MkdirAll(filepath.Dir(target), 0700); e != nil {
		return e
	}
	f, e := os.Create(target)
	if e != nil {
		return e
	}
	success := false
	defer func() {
		_ = f.Close()
		if !success {
			_ = os.Remove(target)
		}
	}()
	hash := sha256.New()
	limit := io.LimitReader(res.Body, size+1)
	buf := make([]byte, 256<<10)
	var total int64
	for {
		n, err := limit.Read(buf)
		if n > 0 {
			if _, e = f.Write(buf[:n]); e != nil {
				return e
			}
			hash.Write(buf[:n])
			total += int64(n)
			if progress != nil {
				progress(total)
			}
		}
		if err == io.EOF {
			break
		}
		if err != nil {
			return err
		}
	}
	if total != size {
		return fmt.Errorf("Boyut uyuşmazlığı: %d / %d", total, size)
	}
	if !strings.EqualFold(hex.EncodeToString(hash.Sum(nil)), expected) {
		return errors.New("SHA-256 doğrulaması başarısız: dosya kullanılmadı")
	}
	if e = f.Sync(); e != nil {
		return e
	}
	if e = f.Close(); e != nil {
		return e
	}
	success = true
	return nil
}
func shaFile(path string) (string, int64, error) {
	f, e := os.Open(path)
	if e != nil {
		return "", 0, e
	}
	defer f.Close()
	h := sha256.New()
	n, e := io.Copy(h, f)
	if e != nil {
		return "", 0, e
	}
	return hex.EncodeToString(h.Sum(nil)), n, nil
}
func createDraft(ctx context.Context, token, tag string) (GHRelease, error) {
	var r GHRelease
	e := githubJSON(ctx, "POST", "/releases", token, map[string]any{"tag_name": tag, "name": "AGALAR " + tag, "draft": true, "prerelease": false, "generate_release_notes": false}, &r)
	return r, e
}
func uploadAsset(ctx context.Context, token string, r GHRelease, name, path string) (ReleaseAsset, error) {
	// GitHub returns a URI-template: https://uploads.github.com/repos/.../assets{?name,label}.
	var asset ReleaseAsset
	base := strings.Split(r.UploadURL, "{")[0]
	u, e := url.Parse(base)
	if e != nil {
		return asset, e
	}
	if u.Scheme != "https" || u.Hostname() != "uploads.github.com" || u.Port() != "" {
		return asset, errors.New("Geçersiz GitHub yükleme adresi")
	}
	q := u.Query()
	q.Set("name", name)
	u.RawQuery = q.Encode()
	f, e := os.Open(path)
	if e != nil {
		return asset, e
	}
	defer f.Close()
	st, e := f.Stat()
	if e != nil {
		return asset, e
	}
	if st.Size() > 2<<30 {
		return asset, errors.New("GitHub tek dosya sınırı 2 GB")
	}
	req, e := http.NewRequestWithContext(ctx, "POST", u.String(), f)
	if e != nil {
		return asset, e
	}
	req.ContentLength = st.Size()
	req.Header.Set("Authorization", "Bearer "+token)
	req.Header.Set("Accept", "application/vnd.github+json")
	req.Header.Set("Content-Type", "application/octet-stream")
	req.Header.Set("User-Agent", "AGALAR-Manager/"+appVersion)
	res, e := transferClient.Do(req)
	if e != nil {
		return asset, e
	}
	defer res.Body.Close()
	if res.StatusCode != 201 {
		b, _ := io.ReadAll(io.LimitReader(res.Body, 2048))
		return asset, fmt.Errorf("GitHub yükleme hatası %d: %s", res.StatusCode, string(b))
	}
	e = json.NewDecoder(io.LimitReader(res.Body, 1<<20)).Decode(&asset)
	return asset, e
}
func publishDraft(ctx context.Context, token string, id int64) error {
	return githubJSON(ctx, "PATCH", fmt.Sprintf("/releases/%d", id), token, map[string]any{"draft": false}, nil)
}
func sortedPackFiles(items []PackFile) {
	sort.Slice(items, func(i, j int) bool { return items[i].Path < items[j].Path })
}
